import { useEffect, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowUpRight,
  Briefcase,
  ChevronRight,
  CircleHelp,
  Code,
  Crown,
  Globe,
  Info,
  LayoutGrid,
  Mic,
  MicOff,
  Monitor,
  PhoneOff,
  Rocket,
  Search,
  Send,
  Sparkles,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { WalletButton } from "@/components/WalletButton";
import { HologramScene } from "@/components/HologramScene";
import { MatrixRain } from "@/components/MatrixRain";
import { ZiggyChatTerminal } from "@/components/ZiggyChatTerminal";
import { useLiveVoice } from "@/hooks/use-live-voice";
import { searchDestination, websiteDestination } from "@/lib/dashboard-actions";
import heroBackground from "@/assets/sakim-hero.jpg";

type Panel = "smart" | "search" | "pc" | "websites" | "apps" | "help" | "limitations" | null;

type Recognition = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  abort(): void;
  onresult:
    | ((event: {
        results: { [key: number]: { [key: number]: { transcript: string } }; length: number };
        resultIndex: number;
      }) => void)
    | null;
  onend: (() => void) | null;
  onerror: ((event: { error: string }) => void) | null;
};

const titles: Record<Exclude<Panel, null>, string> = {
  smart: "Smart AI Actions & Automation",
  search: "Web Search",
  pc: "Control Your PC",
  websites: "Open Websites",
  apps: "Launch Apps",
  help: "Ziggy Neural Terminal — Gemini AI Chat",
  limitations: "Voice Assistant & Browser Permissions",
};

// Multilingual wake-word regex: English, Hindi, Bengali
const WAKE_REGEX = /(ziggy|ziggi|ziggie|जिग्गी|ज़िग्गी|जिगी|জিগি|জিগ্গি|জিগী)/i;

export function AIDashboard() {
  const voice = useLiveVoice();
  const audioLevel = useRef(0);
  const [speaking, setSpeaking] = useState(false);
  const [panel, setPanel] = useState<Panel>(null);
  const [value, setValue] = useState("");
  const [formError, setFormError] = useState("");
  const [wakeEnabled, setWakeEnabled] = useState(true);
  const [wakeSupported, setWakeSupported] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [commandInput, setCommandInput] = useState("");
  const [chatPrompt, setChatPrompt] = useState<string | undefined>(undefined);
  const [selectedLanguage, setSelectedLanguage] = useState<"en" | "hi" | "bn">("en");
  const [assistantMessage, setAssistantMessage] = useState(
    "Namaste! I am Ziggy, your AI Assistant powered by Gemini. How can I help you today?",
  );

  const isListeningRef = useRef(isListening);
  isListeningRef.current = isListening;
  const speakingRef = useRef(speaking);
  speakingRef.current = speaking;
  const lastWakeRef = useRef(0);

  const startRef = useRef(voice.start);
  startRef.current = voice.start;

  const idle = voice.status === "idle" || voice.status === "closed";
  const live = voice.status === "connected";

  // Speech synthesis fallback in Hindi, English, and Bengali
  const speakText = (text: string, lang = selectedLanguage) => {
    setAssistantMessage(text);
    if (!window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.05;

    if (lang === "hi") {
      utterance.lang = "hi-IN";
    } else if (lang === "bn") {
      utterance.lang = "bn-IN";
    } else {
      utterance.lang = "en-US";
    }

    const voices = window.speechSynthesis.getVoices();
    const targetVoice = voices.find(
      (v) =>
        (lang === "hi" && v.lang.startsWith("hi")) ||
        (lang === "bn" && v.lang.startsWith("bn")) ||
        (lang === "en" &&
          (v.name.includes("Male") || v.name.includes("Google") || v.lang.startsWith("en"))),
    );
    if (targetVoice) utterance.voice = targetVoice;

    let simInterval = 0;
    utterance.onstart = () => {
      setSpeaking(true);
      simInterval = window.setInterval(() => {
        audioLevel.current = 0.4 + Math.random() * 0.45;
      }, 70);
    };

    utterance.onend = () => {
      clearInterval(simInterval);
      audioLevel.current = 0;
      setSpeaking(false);
    };

    utterance.onerror = () => {
      clearInterval(simInterval);
      audioLevel.current = 0;
      setSpeaking(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  const speakTextRef = useRef(speakText);
  speakTextRef.current = speakText;

  const handleSmartCommandRef = useRef<(cmd: string) => void>(() => {});

  // Audio analysis when live call is connected
  useEffect(() => {
    if (!live) {
      if (!window.speechSynthesis?.speaking) {
        audioLevel.current = 0;
        setSpeaking(false);
      }
      return;
    }

    const context = new AudioContext();
    const analyser = context.createAnalyser();
    analyser.fftSize = 256;
    const samples = new Uint8Array(analyser.frequencyBinCount);
    let source: MediaStream | null = null;
    let node: MediaStreamAudioSourceNode | null = null;
    let lastSpeaking = false;

    const timer = window.setInterval(() => {
      if (document.hidden) return;
      const stream = voice.audioRef.current?.srcObject;
      if (stream instanceof MediaStream && stream !== source && stream.getAudioTracks().length) {
        source = stream;
        node?.disconnect();
        node = context.createMediaStreamSource(stream);
        node.connect(analyser);
        void context.resume();
      }

      analyser.getByteFrequencyData(samples);
      let sum = 0;
      for (let i = 2; i < 40; i++) sum += samples[i] ?? 0;
      audioLevel.current = Math.min(1, sum / 38 / 140);
      const next = audioLevel.current > 0.06;
      if (next !== lastSpeaking) {
        lastSpeaking = next;
        setSpeaking(next);
      }
    }, 70);

    return () => {
      clearInterval(timer);
      node?.disconnect();
      void context.close();
    };
  }, [live, voice.audioRef]);

  // Wake Word & Continuous Speech Detection
  useEffect(() => {
    const browser = window as typeof window & {
      SpeechRecognition?: new () => Recognition;
      webkitSpeechRecognition?: new () => Recognition;
    };
    const Constructor = browser.SpeechRecognition ?? browser.webkitSpeechRecognition;
    setWakeSupported(Boolean(Constructor));
    if (!Constructor || !wakeEnabled) return;

    const recognition = new Constructor();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang =
      selectedLanguage === "hi" ? "hi-IN" : selectedLanguage === "bn" ? "bn-IN" : "en-US";

    let stopped = false;
    let retry: ReturnType<typeof setTimeout> | undefined;

    recognition.onresult = (event) => {
      // Do not process speech while Ziggy is actively speaking to prevent echo loops
      if (speakingRef.current) return;

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const item = event.results[i];
        const transcript = item?.[0]?.transcript?.trim() ?? "";
        if (!transcript) continue;
        const isFinal = Boolean((item as { isFinal?: boolean })?.isFinal);

        // Check for wake word "Ziggy" (English, Hindi, Bengali)
        if (WAKE_REGEX.test(transcript)) {
          const now = Date.now();
          if (now - lastWakeRef.current < 2500) return;
          lastWakeRef.current = now;

          setIsListening(true);
          isListeningRef.current = true;

          const trailingCommand = transcript.replace(WAKE_REGEX, "").trim();
          if (trailingCommand.length > 1) {
            handleSmartCommandRef.current(trailingCommand);
          } else {
            if (selectedLanguage === "hi") {
              speakTextRef.current("हाँ, मैं सुन रहा हूँ। आज आप क्या करना चाहते हैं?", "hi");
            } else if (selectedLanguage === "bn") {
              speakTextRef.current("হ্যাঁ, আমি শুনছি। আজ আপনাকে কীভাবে সাহায্য করতে পারি?", "bn");
            } else {
              speakTextRef.current("Yes, I'm listening! How can I help you today?", "en");
            }
          }

          // Trigger live voice session if configured
          try {
            startRef.current();
          } catch {
            // speech recognition fallback remains active
          }
          return;
        }

        // If in listening mode and user finished a command sentence
        if (isListeningRef.current && (isFinal || !recognition.interimResults)) {
          handleSmartCommandRef.current(transcript);
          return;
        }
      }
    };

    recognition.onerror = (event) => {
      if (["not-allowed", "service-not-allowed", "audio-capture"].includes(event.error)) {
        stopped = true;
        setWakeEnabled(false);
      }
    };

    recognition.onend = () => {
      if (!stopped) {
        retry = setTimeout(() => {
          try {
            recognition.start();
          } catch {
            // Already active or waiting
          }
        }, 600);
      }
    };

    try {
      recognition.start();
    } catch {
      // Browser may require user gesture first
    }

    const onUserGesture = () => {
      if (!stopped) {
        try {
          recognition.start();
        } catch {
          // already started
        }
      }
    };
    window.addEventListener("pointerdown", onUserGesture, { once: true });

    return () => {
      stopped = true;
      window.removeEventListener("pointerdown", onUserGesture);
      clearTimeout(retry);
      try {
        recognition.abort();
      } catch {
        // ignore
      }
    };
  }, [wakeEnabled, selectedLanguage]);

  const openPanel = (next: Panel) => {
    setValue("");
    setFormError("");
    setPanel(next);
  };

  const submit = (event: React.FormEvent) => {
    event.preventDefault();
    const destination = panel === "search" ? searchDestination(value) : websiteDestination(value);
    if (!destination) {
      setFormError(
        panel === "search" ? "Enter a search term." : "Enter a valid website, such as example.com.",
      );
      return;
    }
    window.open(destination, "_blank", "noopener,noreferrer");
  };

  const begin = () => {
    setPanel(null);
    setIsListening(true);
    isListeningRef.current = true;
    speakText("Yes, I'm listening! Speak whenever you are ready.", selectedLanguage);
    try {
      voice.start();
    } catch {
      // live voice fallback
    }
  };

  // Action execution dispatcher
  const handleExecuteAction = (action: {
    type: "open_url" | "navigate" | "search" | "open_panel";
    target?: string;
    label?: string;
  }) => {
    if (action.type === "open_url" && action.target) {
      window.open(action.target, "_blank", "noopener,noreferrer");
    } else if (action.type === "navigate" && action.target) {
      window.location.assign(action.target);
    } else if (action.type === "search" && action.target) {
      const dest = searchDestination(action.target);
      if (dest) window.open(dest, "_blank", "noopener,noreferrer");
    } else if (action.type === "open_panel" && action.target) {
      openPanel(action.target as Panel);
    }
  };

  // Smart command execution powered by Google Gemini AI
  const handleSmartCommand = async (cmd: string, openChatModal = false) => {
    const text = cmd.trim();
    if (!text) return;

    // Fast stop / pause commands
    if (/^(stop|cancel|bye|goodbye|quiet|अलविदा|रुकें|থামো|বিদায়)$/i.test(text)) {
      setIsListening(false);
      isListeningRef.current = false;
      if (selectedLanguage === "hi") {
        speakText("ठीक है, मैं रुकता हूँ। जब भी जरूरत हो, 'Ziggy' बोलें।", "hi");
      } else if (selectedLanguage === "bn") {
        speakText("ঠিক আছে, আমি থামছি। যখনই প্রয়োজন হবে, 'Ziggy' বলুন।", "bn");
      } else {
        speakText("Alright, standing by. Just say 'Ziggy' whenever you need me.", "en");
      }
      setCommandInput("");
      return;
    }

    if (openChatModal) {
      setChatPrompt(text);
      openPanel("help");
      setCommandInput("");
      return;
    }

    setAssistantMessage("Thinking with Gemini AI...");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          language: selectedLanguage,
          enableSearch: true,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const replyText: string = data.reply || "I received your request.";

        // Clean speech text by removing markdown tags for natural speech synthesis
        const cleanVoice = replyText
          .replace(/```[\s\S]*?```/g, "Code generated.")
          .replace(/`([^`]+)`/g, "$1")
          .replace(/[*_#>[\]]/g, "")
          .slice(0, 240);

        speakText(cleanVoice, selectedLanguage);

        if (data.action) {
          handleExecuteAction(data.action);
        }
        setCommandInput("");
        return;
      }
    } catch (err) {
      console.error("Gemini Assistant error:", err);
    }

    // Direct browser fallback for quick offline execution
    const lower = text.toLowerCase();
    if (lower.startsWith("search ") || lower.startsWith("google ") || lower.startsWith("find ")) {
      const q = lower.replace(/^(search|google|find)\s+/i, "");
      const dest = searchDestination(q);
      if (dest) {
        speakText(`Searching Google for ${q}`, selectedLanguage);
        window.open(dest, "_blank", "noopener,noreferrer");
        setCommandInput("");
        return;
      }
    }

    if (lower.includes("youtube")) {
      speakText("Opening YouTube", selectedLanguage);
      window.open("https://www.youtube.com", "_blank", "noopener,noreferrer");
      setCommandInput("");
      return;
    }
    if (lower.includes("gmail") || lower.includes("mail")) {
      speakText("Opening Gmail", selectedLanguage);
      window.open("https://mail.google.com", "_blank", "noopener,noreferrer");
      setCommandInput("");
      return;
    }
    if (lower.includes("google drive") || lower.includes("drive")) {
      speakText("Opening Google Drive", selectedLanguage);
      window.open("https://drive.google.com", "_blank", "noopener,noreferrer");
      setCommandInput("");
      return;
    }
    if (lower.includes("calendar")) {
      speakText("Opening Google Calendar", selectedLanguage);
      window.open("https://calendar.google.com", "_blank", "noopener,noreferrer");
      setCommandInput("");
      return;
    }

    if (
      lower.includes("create token") ||
      lower.includes("new token") ||
      lower.includes("builder")
    ) {
      speakText("Opening the SAKIM Token Builder", selectedLanguage);
      window.location.assign("/create");
      setCommandInput("");
      return;
    }
    if (lower.includes("my tokens") || lower.includes("view tokens")) {
      speakText("Opening your saved Token Previews", selectedLanguage);
      window.location.assign("/tokens");
      setCommandInput("");
      return;
    }
    if (lower.includes("launchpad") || lower.includes("launch")) {
      speakText("Opening SAKIM Launchpad roadmap", selectedLanguage);
      window.location.assign("/launchpad");
      setCommandInput("");
      return;
    }

    if (lower.includes("pc") || lower.includes("computer") || lower.includes("control")) {
      openPanel("pc");
      speakText(
        "For security, direct PC OS control requires an authorized companion program. You can launch web apps right now.",
        selectedLanguage,
      );
      setCommandInput("");
      return;
    }

    if (selectedLanguage === "hi") {
      speakText(`मैंने आपकी कमांड सुनी: "${cmd}".`, "hi");
    } else if (selectedLanguage === "bn") {
      speakText(`আমি আপনার কমান্ড পেয়েছি: "${cmd}".`, "bn");
    } else {
      speakText(`I processed your request: "${cmd}".`, "en");
    }
    setCommandInput("");
  };

  handleSmartCommandRef.current = handleSmartCommand;

  const status =
    voice.status === "connecting"
      ? "Connecting..."
      : voice.status === "stopping"
        ? "Ending..."
        : live
          ? voice.muted
            ? "Muted"
            : speaking
              ? "Speaking..."
              : "Listening..."
          : speaking
            ? "Speaking..."
            : isListening || wakeEnabled
              ? "Listening..."
              : "Tap to Speak";

  return (
    <div className="sakim-main-screen">
      {/* Background Cyber City + Hologram Matrix Rain */}
      <img
        src={heroBackground}
        className="sakim-bg-city pointer-events-none absolute inset-0 h-full w-full object-cover opacity-60"
        alt=""
        aria-hidden="true"
      />
      <MatrixRain opacity={0.3} />
      <div
        className="sakim-ambient-vignette pointer-events-none absolute inset-0"
        aria-hidden="true"
      />

      {/* TOP HEADER - Exact Reference Layout */}
      <header className="sakim-top-header">
        {/* Top Left: SAKIM Crown Hexagon Emblem */}
        <Link to="/" className="sakim-emblem-badge group" title="SAKIM AI">
          <div className="emblem-inner">
            <Crown className="emblem-crown h-4 w-4" />
            <div className="emblem-letter">S</div>
            <span className="emblem-label">SAKIM</span>
          </div>
        </Link>

        {/* Top Center: Futuristic HUD Title Banner */}
        <div className="sakim-banner-title">
          <div className="banner-border-line-left" />
          <div className="banner-content">
            <h1>
              Sakim AI <span>Assistant</span>
            </h1>
            <p>— Your Smart Personal Assistant —</p>
          </div>
          <div className="banner-border-line-right" />
        </div>

        {/* Top Right: MetaMask Connected Badge */}
        <div className="sakim-top-right">
          <WalletButton variant="hud-pill" />
        </div>
      </header>

      {/* MAIN 3-COLUMN STAGE */}
      <main className="sakim-grid-stage">
        {/* LEFT COLUMN: 4 Cyber Action Buttons */}
        <aside className="sakim-column sakim-column-left" aria-label="Left Controls">
          {/* 1. Voice Control */}
          <button
            onClick={begin}
            className="hud-action-card group"
            title="Talk to Sakim Voice Assistant"
          >
            <div className="card-icon-frame bg-blue-500/20 text-cyan-400 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
              <Mic className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Voice Control</h3>
              <p>Talk to Sakim</p>
            </div>
          </button>

          {/* 2. Smart Actions */}
          <button
            onClick={() => openPanel("smart")}
            className="hud-action-card group"
            title="Open Smart Actions"
          >
            <div className="card-icon-frame bg-amber-500/20 text-amber-300 border border-amber-400/50 shadow-[0_0_12px_rgba(255,208,91,0.4)]">
              <Zap className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Smart Actions</h3>
              <p>Do more easily</p>
            </div>
          </button>

          {/* 3. Web Search */}
          <button
            onClick={() => openPanel("search")}
            className="hud-action-card group"
            title="Search the Web"
          >
            <div className="card-icon-frame bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
              <Globe className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Web Search</h3>
              <p>Find anything</p>
            </div>
          </button>

          {/* 4. Project Builder */}
          <button
            onClick={() => window.location.assign("/create")}
            className="hud-action-card group"
            title="Launch Project Builder"
          >
            <div className="card-icon-frame bg-amber-500/20 text-amber-300 border border-amber-400/50 shadow-[0_0_12px_rgba(255,208,91,0.4)]">
              <Briefcase className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Project Builder</h3>
              <p>Build &amp; Innovate</p>
            </div>
          </button>
        </aside>

        {/* CENTER HERO: Realistic Animated 3D Male Avatar + Ziggy Nameplate */}
        <section className="sakim-center-hero">
          {/* 3D Animated Scene: realistic human-like male avatar */}
          <div className="avatar-canvas-wrapper">
            {/* Subtle falling numbers directly behind reference avatar */}
            <MatrixRain
              className="avatar-numbers-rain pointer-events-none absolute inset-0 z-0"
              opacity={0.32}
            />
            <HologramScene
              audioLevel={audioLevel}
              isLive={live || isListening || wakeEnabled}
              isSpeaking={speaking}
              isMuted={voice.muted}
            />
          </div>

          {/* ZIGGY NAMEPLATE - Exactly matching reference */}
          <div className="ziggy-nameplate-plate">
            {/* Left Audio Waveform Bars */}
            <div className="nameplate-wave wave-left" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
              <span />
            </div>

            {/* Center Golden Branding */}
            <div className="nameplate-branding">
              <h2>Ziggy</h2>
              <p>Voice Assistant</p>
            </div>

            {/* Right Audio Waveform Bars */}
            <div className="nameplate-wave wave-right" aria-hidden="true">
              <span />
              <span />
              <span />
              <span />
              <span />
            </div>
          </div>

          {/* Interactive Speech Subtitle ticker */}
          <p className="avatar-speech-ticker truncate" role="status">
            "{assistantMessage}"
          </p>

          {/* Language selector & Wake word badge */}
          <div className="avatar-control-strip">
            <div className="lang-pill">
              <button
                type="button"
                onClick={() => setSelectedLanguage("hi")}
                className={`lang-btn ${selectedLanguage === "hi" ? "active" : ""}`}
              >
                हिन्दी
              </button>
              <span className="dot">•</span>
              <button
                type="button"
                onClick={() => setSelectedLanguage("en")}
                className={`lang-btn ${selectedLanguage === "en" ? "active" : ""}`}
              >
                English
              </button>
              <span className="dot">•</span>
              <button
                type="button"
                onClick={() => setSelectedLanguage("bn")}
                className={`lang-btn ${selectedLanguage === "bn" ? "active" : ""}`}
              >
                বাংলা
              </button>
            </div>

            <button
              type="button"
              onClick={() => setWakeEnabled(!wakeEnabled)}
              className={`wake-pill ${wakeEnabled ? "enabled" : ""}`}
              title="Continuous wake word detection for 'Ziggy'"
            >
              <span className="indicator-dot" />
              Wake: “Ziggy”
            </button>

            <button
              type="button"
              onClick={() => openPanel("limitations")}
              className="info-btn"
              title="Browser voice requirements and permissions"
            >
              <Info className="h-3.5 w-3.5" />
            </button>
          </div>
        </section>

        {/* RIGHT COLUMN: 4 Cyber Action Buttons */}
        <aside className="sakim-column sakim-column-right" aria-label="Right Controls">
          {/* 1. Control Your PC */}
          <button
            onClick={() => openPanel("pc")}
            className="hud-action-card group"
            title="Control Your PC (With Permission)"
          >
            <div className="card-icon-frame bg-blue-500/20 text-cyan-400 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
              <Monitor className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Control Your PC</h3>
              <p>With Permission</p>
            </div>
          </button>

          {/* 2. Open Websites */}
          <button
            onClick={() => openPanel("websites")}
            className="hud-action-card group"
            title="Open Websites Freely"
          >
            <div className="card-icon-frame bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
              <Globe className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Open Websites</h3>
              <p>Browse Freely</p>
            </div>
          </button>

          {/* 3. Launch Apps */}
          <button
            onClick={() => openPanel("apps")}
            className="hud-action-card group"
            title="Launch Web Apps"
          >
            <div className="card-icon-frame bg-blue-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_12px_rgba(0,240,255,0.4)]">
              <LayoutGrid className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Launch Apps</h3>
              <p>Open Apps</p>
            </div>
          </button>

          {/* 4. Chat & Help */}
          <button
            onClick={() => openPanel("help")}
            className="hud-action-card group"
            title="Chat & Ask Questions"
          >
            <div className="card-icon-frame bg-purple-500/20 text-purple-200 border border-purple-400/50 shadow-[0_0_12px_rgba(168,85,247,0.4)]">
              <CircleHelp className="h-6 w-6 transition-transform group-hover:scale-110" />
            </div>
            <div className="card-text">
              <h3>Chat &amp; Help</h3>
              <p>Ask Anything</p>
            </div>
          </button>
        </aside>
      </main>

      {/* BOTTOM DOCK BAR - Exact Reference Layout */}
      <footer className="sakim-bottom-dock">
        {/* 1. Create Token Button */}
        <Link to="/create" className="dock-card group" title="Create Token - Launch Your Token">
          {/* Stack of Gold Coins Icon */}
          <div className="dock-icon-gold">
            <svg viewBox="0 0 32 32" className="h-7 w-7" aria-hidden="true">
              <ellipse
                cx="16"
                cy="7"
                rx="10"
                ry="3.5"
                fill="#ffd05b"
                stroke="#e09e19"
                strokeWidth="1.5"
              />
              <path
                d="M6 7v6c0 1.9 4.5 3.5 10 3.5s10-1.6 10-3.5V7"
                fill="#f5b82e"
                stroke="#e09e19"
                strokeWidth="1.5"
              />
              <path
                d="M6 13v6c0 1.9 4.5 3.5 10 3.5s10-1.6 10-3.5V13"
                fill="#e09e19"
                stroke="#b87b08"
                strokeWidth="1.5"
              />
              <path
                d="M6 19v6c0 1.9 4.5 3.5 10 3.5s10-1.6 10-3.5V19"
                fill="#c48507"
                stroke="#8a5b00"
                strokeWidth="1.5"
              />
            </svg>
          </div>
          <div className="dock-text">
            <h4>Create Token</h4>
            <p>Launch Your Token</p>
          </div>
          <ChevronRight className="dock-arrow text-cyan-400" />
        </Link>

        {/* 2. My Tokens Button */}
        <Link to="/tokens" className="dock-card group" title="My Tokens - View Your Tokens">
          {/* Ethereum Diamond Icon */}
          <div className="dock-icon-eth">
            <svg viewBox="0 0 32 32" className="h-7 w-7" aria-hidden="true">
              <polygon
                points="16,4 7,16 16,21 25,16"
                fill="#88ccff"
                stroke="#00f0ff"
                strokeWidth="1.2"
              />
              <polygon
                points="16,21 7,16 16,28 25,16"
                fill="#3399ff"
                stroke="#0088ff"
                strokeWidth="1.2"
              />
              <polygon points="16,4 16,21 25,16" fill="#b3e0ff" />
              <polygon points="16,21 16,28 25,16" fill="#66b3ff" />
            </svg>
          </div>
          <div className="dock-text">
            <h4>My Tokens</h4>
            <p>View Your Tokens</p>
          </div>
        </Link>

        {/* 3. Center Voice Console Pill: Listening... */}
        <div className="dock-center-pill">
          <button
            onClick={() => {
              if (speaking) {
                window.speechSynthesis?.cancel();
                setSpeaking(false);
                return;
              }
              if (isListening) {
                setIsListening(false);
                isListeningRef.current = false;
                speakText("Standing by. Say 'Ziggy' anytime.", selectedLanguage);
              } else {
                begin();
              }
            }}
            className={`console-voice-btn ${live || isListening ? "is-live" : ""} ${speaking ? "is-speaking" : ""}`}
            title={isListening ? "Stop Listening" : "Start Voice Listening"}
          >
            {/* Left Sound Broadcast Waves */}
            <div className="sound-broadcast-left" aria-hidden="true">
              <span className="wave-arc arc-1" />
              <span className="wave-arc arc-2" />
              <span className="wave-arc arc-3" />
            </div>

            {/* Microphone Icon */}
            <div className="mic-badge">
              {voice.muted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
            </div>

            {/* Listening Status Text */}
            <div className="console-status-text">
              <span>{status}</span>
            </div>

            {/* Right Equalizer Spectrum Waves */}
            <div className="sound-spectrum-right" aria-hidden="true">
              <span className="bar bar-1" />
              <span className="bar bar-2" />
              <span className="bar bar-3" />
              <span className="bar bar-4" />
              <span className="bar bar-5" />
            </div>
          </button>

          {!idle && (
            <button onClick={voice.stop} className="console-end-call" title="End Voice Call">
              <PhoneOff className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* 4. Launchpad Button */}
        <Link to="/launchpad" className="dock-card group" title="Launchpad - Start New Project">
          {/* Rocket Icon */}
          <div className="dock-icon-rocket">
            <Rocket className="h-6 w-6 text-pink-400 drop-shadow-[0_0_8px_#ec4899]" />
          </div>
          <div className="dock-text">
            <h4>Launchpad</h4>
            <p>Start New Project</p>
          </div>
          <ArrowUpRight className="dock-arrow text-white" />
        </Link>
      </footer>

      {/* QUICK COMMAND PROMPT OVERLAY */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (commandInput.trim()) {
            handleSmartCommand(commandInput, true);
          }
        }}
        className="sakim-floating-prompt"
      >
        <Input
          value={commandInput}
          onChange={(e) => setCommandInput(e.target.value)}
          placeholder="Ask Ziggy anything (e.g. 'write an ERC-20 contract', 'latest bitcoin price', 'open youtube')..."
          className="prompt-input"
        />
        <Button type="submit" size="icon" variant="ghost" className="prompt-send-btn">
          <Send className="h-4 w-4" />
        </Button>
      </form>

      <audio ref={voice.audioRef} className="sr-only" />

      {/* MODAL PANELS (Smart Actions, Search, PC Control, Websites, Apps, Help) */}
      <Dialog
        open={panel !== null}
        onOpenChange={(open) => {
          if (!open) setPanel(null);
        }}
      >
        <DialogContent
          className={`sakim-hud-dialog ${panel === "help" ? "sm:max-w-3xl w-[94vw]" : "sm:max-w-lg"}`}
        >
          <DialogHeader>
            <DialogTitle className="font-display text-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]">
              {panel ? titles[panel] : ""}
            </DialogTitle>
            <DialogDescription className="text-muted-foreground text-xs">
              {panel === "search"
                ? "Search Google securely in a new browser tab."
                : panel === "websites"
                  ? "Enter or choose a website destination to open."
                  : panel === "pc"
                    ? "Computer Control & OS Privacy Isolation Notice."
                    : panel === "apps"
                      ? "Choose a web application to launch."
                      : panel === "limitations"
                        ? "Voice recognition capabilities & browser permissions."
                        : panel === "smart"
                          ? "Intelligent AI-powered actions and rapid project tools."
                          : "Intelligent ChatGPT-style AI terminal powered by Google Gemini."}
            </DialogDescription>
          </DialogHeader>

          {/* Chat & Help Panel: Full-fledged ChatGPT-style Gemini AI Terminal */}
          {panel === "help" && (
            <ZiggyChatTerminal
              selectedLanguage={selectedLanguage}
              onSelectLanguage={setSelectedLanguage}
              onSpeak={speakText}
              onExecuteAction={handleExecuteAction}
              externalPrompt={chatPrompt}
              onPromptHandled={() => setChatPrompt(undefined)}
            />
          )}

          {/* Search or Websites Form */}
          {(panel === "search" || panel === "websites") && (
            <form onSubmit={submit} className="space-y-4">
              <label className="block space-y-2 text-sm text-foreground">
                <span>{panel === "search" ? "Search query" : "Website address"}</span>
                <Input
                  autoFocus
                  value={value}
                  onChange={(event) => setValue(event.target.value)}
                  placeholder={panel === "search" ? "What would you like to find?" : "example.com"}
                  className="bg-black/60 border-cyan-400/40 text-foreground"
                />
              </label>
              {formError && (
                <p role="alert" className="text-xs text-red-400">
                  {formError}
                </p>
              )}
              <Button
                type="submit"
                className="w-full bg-cyan-500 hover:bg-cyan-400 text-black font-bold"
              >
                <Search className="mr-1.5 h-4 w-4" />{" "}
                {panel === "search" ? "Search Google" : "Open Website"}
                <ArrowUpRight className="ml-1.5 h-4 w-4" />
              </Button>
            </form>
          )}

          {/* PC Control Panel (Explicit Browser Security Notice) */}
          {panel === "pc" && (
            <div className="space-y-4">
              <div className="rounded-lg border border-cyan-400/40 bg-cyan-950/30 p-3.5 text-xs text-cyan-100">
                <p className="font-semibold text-cyan-300 flex items-center gap-1.5">
                  <Monitor className="h-4 w-4" /> Browser Security Isolation Active
                </p>
                <p className="mt-1.5 leading-relaxed text-muted-foreground">
                  Web browsers execute in a secure sandbox. Websites cannot run local native
                  binaries, format drives, or access private filesystem files without an authorized
                  native companion program.
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                You can safely launch web-based tools and applications from your browser right now:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  variant="outline"
                  onClick={() => openPanel("apps")}
                  className="border-cyan-400/40"
                >
                  <LayoutGrid className="mr-1.5 h-4 w-4 text-cyan-400" /> Open Web Apps
                </Button>
                <Button
                  variant="outline"
                  onClick={() => openPanel("websites")}
                  className="border-cyan-400/40"
                >
                  <Globe className="mr-1.5 h-4 w-4 text-cyan-400" /> Open Websites
                </Button>
              </div>
            </div>
          )}

          {/* Launch Apps Panel */}
          {panel === "apps" && (
            <div className="grid grid-cols-2 gap-3">
              {[
                ["YouTube", "https://www.youtube.com"],
                ["Gmail", "https://mail.google.com"],
                ["Google Drive", "https://drive.google.com"],
                ["Google Calendar", "https://calendar.google.com"],
                ["GitHub", "https://github.com"],
                ["X / Twitter", "https://twitter.com"],
              ].map(([name, url]) => (
                <Button
                  key={name}
                  asChild
                  variant="outline"
                  className="justify-between border-cyan-400/30 bg-black/40 hover:border-cyan-400 hover:bg-cyan-500/10"
                >
                  <a href={url} target="_blank" rel="noopener noreferrer">
                    {name}
                    <ArrowUpRight className="h-4 w-4 text-cyan-400" />
                  </a>
                </Button>
              ))}
            </div>
          )}

          {/* Browser Limitations and Permission Notice */}
          {panel === "limitations" && (
            <div className="space-y-3 text-xs text-muted-foreground">
              <p>
                <strong className="text-foreground">Microphone Access:</strong> Browser permission
                is required for voice recognition and conversations. You will be prompted by the
                browser when activated.
              </p>
              <p>
                <strong className="text-foreground">Continuous Wake Word:</strong> When enabled,
                Ziggy listens for "Ziggy" (or हिन्दी: "जिग्गी", বাংলা: "জিগি") while this browser
                tab remains open.
              </p>
              <p>
                <strong className="text-foreground">Background Listening Notice:</strong> Standard
                web browsers suspend microphone capture when tabs are minimized or closed to protect
                user privacy.
              </p>
              <p>
                <strong className="text-foreground">Supported Languages:</strong> English, Hindi
                (हिन्दी), and Bengali (বাংলা).
              </p>
            </div>
          )}

          {/* Smart AI Actions & Project Builder Panel */}
          {panel === "smart" && (
            <div className="grid gap-3">
              <Button
                onClick={() => {
                  setChatPrompt(
                    "Help me architect a complete tokenomics model, token supply, and name for a new AI utility token.",
                  );
                  openPanel("help");
                }}
                className="bg-cyan-500 hover:bg-cyan-400 text-black font-bold justify-between"
              >
                <span className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4" /> AI Token Architect (Gemini)
                </span>
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => {
                  setChatPrompt(
                    "Write a production-ready, audited ERC-20 smart contract in Solidity with mint, burn, and pausable features.",
                  );
                  openPanel("help");
                }}
                variant="outline"
                className="justify-between border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/10"
              >
                <span className="flex items-center gap-2">
                  <Code className="h-4 w-4 text-cyan-400" /> Smart Contract Generator
                </span>
                <ChevronRight className="h-4 w-4 text-cyan-400" />
              </Button>
              <Button
                onClick={() => {
                  setChatPrompt(
                    "Search and summarize the latest cryptocurrency market trends, Bitcoin movements, and regulatory news today.",
                  );
                  openPanel("help");
                }}
                variant="outline"
                className="justify-between border-cyan-400/40 text-cyan-200 hover:bg-cyan-500/10"
              >
                <span className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-cyan-400" /> Live Market Intelligence
                </span>
                <ChevronRight className="h-4 w-4 text-cyan-400" />
              </Button>
              <Button asChild variant="outline" className="justify-between border-cyan-400/40">
                <Link to="/create">
                  <span className="flex items-center gap-2">
                    <Zap className="h-4 w-4 text-amber-300" /> Create Token Preview
                  </span>
                  <ChevronRight className="h-4 w-4 text-cyan-400" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="justify-between border-cyan-400/40">
                <Link to="/tokens">
                  <span>My Saved Tokens</span>
                  <ChevronRight className="h-4 w-4 text-cyan-400" />
                </Link>
              </Button>
              <Button asChild variant="outline" className="justify-between border-cyan-400/40">
                <Link to="/launchpad">
                  <span>Launchpad Roadmap</span>
                  <ChevronRight className="h-4 w-4 text-cyan-400" />
                </Link>
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
