# Dashboard redesign

- [ ] Create reference-inspired blue-and-gold dashboard and animated female avatar.
- [ ] Connect all eight actions to existing voice, token pages or safe browser actions; disclose unavailable PC control.
- [ ] Verify desktop/mobile appearance, actions and existing tests.
