import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Check, Copy, ExternalLink, ShieldCheck } from "lucide-react";
import { DemoBadge, Shell } from "@/components/Shell";
import { loadTokens, removeToken, type PreviewToken } from "@/lib/tokens";

export const Route = createFileRoute("/tokens")({
  head: () => ({
    meta: [
      { title: "My Tokens — SAKIM Launchpad" },
      { name: "description", content: "Your deployed BEP-20 tokens and saved token previews." },
      { property: "og:title", content: "My Tokens — SAKIM Launchpad" },
      {
        property: "og:description",
        content: "Your deployed BEP-20 tokens and saved token previews.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Tokens,
});

function Tokens() {
  const [tokens, setTokens] = useState<PreviewToken[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => setTokens(loadTokens()), []);

  const copyAddress = (addr: string, id: string) => {
    navigator.clipboard.writeText(addr);
    setCopiedId(id);
    toast.success("Contract address copied!");
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <Shell title="My Tokens">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm text-muted-foreground">
          Manage your verified BEP-20 tokens and local previews.
        </p>
        <Link to="/create" className="btn-neon text-xs font-bold px-3.5 py-1.5 rounded-lg">
          + Create New Token
        </Link>
      </div>

      {tokens.length === 0 ? (
        <div className="glass p-8 text-center space-y-4 border border-cyan-400/30">
          <p className="text-muted-foreground">No tokens created yet.</p>
          <Link to="/create" className="btn-neon inline-block rounded-xl px-6 py-3 font-bold">
            Create BEP-20 Token
          </Link>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {tokens.map((t) => {
            const isDeployed = t.status === "deployed" && t.contractAddress;
            return (
              <div
                key={t.id}
                className={`glass space-y-3.5 p-5 border transition-all ${
                  isDeployed
                    ? "border-green-400/50 bg-black/60 shadow-[0_0_15px_rgba(34,197,94,0.15)]"
                    : "border-cyan-400/30"
                }`}
              >
                <div className="flex items-center justify-between">
                  {isDeployed ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold bg-green-500/20 text-green-300 border border-green-400/40">
                      <ShieldCheck className="h-3 w-3" /> BEP-20 Deployed
                    </span>
                  ) : (
                    <DemoBadge label="Draft Preview" />
                  )}

                  <button
                    onClick={() => {
                      removeToken(t.id);
                      setTokens(loadTokens());
                      toast.success("Token removed");
                    }}
                    className="text-xs text-muted-foreground hover:text-destructive transition-colors"
                  >
                    Delete
                  </button>
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className={`grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full border ${
                      isDeployed ? "border-green-400" : "border-primary"
                    }`}
                  >
                    {t.logo ? (
                      <img src={t.logo} alt="" className="h-full w-full object-cover" />
                    ) : (
                      <span
                        className={`font-display text-sm font-bold ${
                          isDeployed ? "text-green-300" : "text-primary"
                        }`}
                      >
                        {t.symbol.slice(0, 3)}
                      </span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-display font-bold truncate text-foreground">{t.name}</p>
                    <p
                      className={`text-sm font-mono ${isDeployed ? "text-green-400" : "text-primary"}`}
                    >
                      ${t.symbol}
                    </p>
                  </div>
                </div>

                <div className="space-y-1 text-xs text-muted-foreground border-t border-cyan-400/20 pt-2.5">
                  <div className="flex justify-between">
                    <span>Supply:</span>
                    <span className="font-mono text-foreground">{t.supply.toLocaleString()}</span>
                  </div>

                  {isDeployed && (
                    <>
                      <div className="flex justify-between">
                        <span>Network:</span>
                        <span className="text-cyan-300 font-semibold">BNB Smart Chain</span>
                      </div>
                      {t.serviceFeePaidUsd && (
                        <div className="flex justify-between">
                          <span>Service Fee Paid:</span>
                          <span className="text-amber-300 font-mono">
                            ${t.serviceFeePaidUsd.toFixed(2)} USD
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Contract Address & Explorer */}
                {isDeployed && t.contractAddress && (
                  <div className="rounded bg-black/60 p-2 border border-green-400/30 text-xs space-y-1.5">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-muted-foreground">Contract:</span>
                      <button
                        type="button"
                        onClick={() => copyAddress(t.contractAddress!, t.id)}
                        className="flex items-center gap-1 text-green-400 hover:text-white"
                      >
                        {copiedId === t.id ? (
                          <Check className="h-3 w-3 text-green-300" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                        <span>{copiedId === t.id ? "Copied" : "Copy"}</span>
                      </button>
                    </div>
                    <p className="font-mono text-[11px] text-green-200 truncate select-all">
                      {t.contractAddress}
                    </p>
                    {t.explorerUrl && (
                      <a
                        href={t.explorerUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-cyan-300 hover:text-white underline pt-0.5"
                      >
                        <ExternalLink className="h-3 w-3" /> View on BscScan
                      </a>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </Shell>
  );
}
