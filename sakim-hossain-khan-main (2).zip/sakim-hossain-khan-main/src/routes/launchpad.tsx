import { createFileRoute } from "@tanstack/react-router";
import { DemoBadge, Shell } from "@/components/Shell";

export const Route = createFileRoute("/launchpad")({
  head: () => ({
    meta: [
      { title: "Launchpad — SAKIM Crypto Creator" },
      {
        name: "description",
        content: "The roadmap from token preview to testnet and mainnet launch.",
      },
      { property: "og:title", content: "Launchpad — SAKIM Crypto Creator" },
      { property: "og:description", content: "The roadmap from token preview to launch." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Launchpad,
});

const STEPS = [
  ["Design & preview", "Available now", true],
  ["Connect wallet (MetaMask)", "Available now", true],
  ["Testnet deployment", "Coming Soon", false],
  ["Security review", "Coming Soon", false],
  ["Mainnet launch", "Coming Soon", false],
] as const;

function Launchpad() {
  return (
    <Shell title="Launchpad">
      <div className="mb-4">
        <DemoBadge label="Coming Soon" />
      </div>
      <ol className="space-y-3">
        {STEPS.map(([t, s, on], i) => (
          <li key={t} className={`glass flex items-center gap-4 p-4 ${on ? "" : "opacity-60"}`}>
            <span className="grid h-9 w-9 place-items-center rounded-full border border-primary font-display text-primary">
              {i + 1}
            </span>
            <span className="flex-1 font-semibold">{t}</span>
            <span className={`text-xs ${on ? "text-primary" : "text-gold"}`}>{s}</span>
          </li>
        ))}
      </ol>
      <p className="mt-6 text-xs text-muted-foreground">
        Real deployment needs network fees and testing. Creating a token never guarantees an
        exchange listing.
      </p>
    </Shell>
  );
}
