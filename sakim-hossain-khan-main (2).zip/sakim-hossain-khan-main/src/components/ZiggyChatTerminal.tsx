import { useEffect, useRef, useState } from "react";
import {
  Bot,
  Check,
  Code,
  Copy,
  ExternalLink,
  Globe,
  Loader2,
  Mic,
  Send,
  Sparkles,
  Trash2,
  User,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  content: string;
  timestamp: number;
  sources?: Array<{ title: string; url: string }>;
  action?: {
    type: "open_url" | "navigate" | "search" | "open_panel";
    target?: string;
    label?: string;
  };
}

interface ZiggyChatTerminalProps {
  selectedLanguage: "en" | "hi" | "bn";
  onSelectLanguage: (lang: "en" | "hi" | "bn") => void;
  onSpeak: (text: string, lang?: "en" | "hi" | "bn") => void;
  onExecuteAction: (action: {
    type: "open_url" | "navigate" | "search" | "open_panel";
    target?: string;
    label?: string;
  }) => void;
  externalPrompt?: string;
  onPromptHandled?: () => void;
}

const STORAGE_KEY = "sakim_ziggy_gemini_memory_v1";

const QUICK_PROMPTS = [
  {
    label: "🚀 Token Architect",
    prompt: "Help me design a tokenomics model and name for a new AI utility token.",
  },
  {
    label: "💻 Solidity Contract",
    prompt: "Write an audited ERC-20 smart contract with minting and burning in Solidity.",
  },
  {
    label: "🌐 Real-Time Crypto News",
    prompt: "What are the latest cryptocurrency market trends and Bitcoin news right now?",
  },
  {
    label: "⚡ SAKIM Features",
    prompt: "Explain the key features of the SAKIM AI Assistant and Launchpad.",
  },
  {
    label: "🇮🇳 हिन्दी में समझाओ",
    prompt: "साकिम एआई और ज़िग्गी वॉइस असिस्टेंट की विशेषताएँ हिन्दी में बताएं।",
  },
  {
    label: "🇧🇩 বাংলায় বলো",
    prompt: "সাকিম এআই সহকারী কীভাবে আমাকে ক্রিপ্টো টোকেন তৈরি করতে সাহায্য করবে?",
  },
];

export function ZiggyChatTerminal({
  selectedLanguage,
  onSelectLanguage,
  onSpeak,
  onExecuteAction,
  externalPrompt,
  onPromptHandled,
}: ZiggyChatTerminalProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return [
      {
        id: "welcome",
        role: "model",
        content:
          "Namaste! I am **Ziggy**, your intelligent AI Assistant powered by **Google Gemini 3.8 Flash**.\n\nI can write code, search the web with live Google grounding, design crypto tokens, execute system actions, and chat fluently in **English**, **हिन्दी**, and **বাংলা**.\n\nHow can I help you innovate today?",
        timestamp: Date.now(),
      },
    ];
  });

  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Sync to local storage for long-term memory
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(messages.slice(-30)));
    } catch {
      // ignore storage quota errors
    }
  }, [messages]);

  // Auto-scroll on new messages
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, loading]);

  const onPromptHandledRef = useRef(onPromptHandled);
  onPromptHandledRef.current = onPromptHandled;

  // Handle prompt passed from external (e.g. voice or floating bar)
  useEffect(() => {
    if (externalPrompt && externalPrompt.trim()) {
      void handleSendMessage(externalPrompt);
      onPromptHandledRef.current?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [externalPrompt]);

  const handleSendMessage = async (textToSend: string) => {
    const query = textToSend.trim();
    if (!query || loading) return;

    const userMessage: ChatMessage = {
      id: `usr_${Date.now()}`,
      role: "user",
      content: query,
      timestamp: Date.now(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setLoading(true);

    try {
      // Build conversation history payload
      const historyPayload = messages.slice(-10).map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: query,
          history: historyPayload,
          language: selectedLanguage,
          enableSearch: true,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server returned ${res.status}`);
      }

      const data = await res.json();
      const replyText = data.reply || "I received your message.";

      const aiMessage: ChatMessage = {
        id: `ai_${Date.now()}`,
        role: "model",
        content: replyText,
        timestamp: Date.now(),
        sources: data.sources,
        action: data.action,
      };

      setMessages((prev) => [...prev, aiMessage]);

      // Speak natural voice response (strip markdown tags for cleaner speech)
      const cleanVoiceText = replyText
        .replace(/```[\s\S]*?```/g, "Code snippet generated.")
        .replace(/`([^`]+)`/g, "$1")
        .replace(/[*_#>[\]]/g, "")
        .slice(0, 240);

      onSpeak(cleanVoiceText, selectedLanguage);

      // Execute command action if attached
      if (data.action) {
        onExecuteAction(data.action);
      }
    } catch (error) {
      console.error("Gemini Chat Error:", error);
      const errorMessage: ChatMessage = {
        id: `err_${Date.now()}`,
        role: "model",
        content:
          "⚠️ I encountered an issue contacting the Gemini AI service. If you are offline or quota is exceeded, I will continue handling local commands.",
        timestamp: Date.now(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearMemory = () => {
    const fresh: ChatMessage[] = [
      {
        id: `init_${Date.now()}`,
        role: "model",
        content: "Conversation memory cleared. Ready for a new topic!",
        timestamp: Date.now(),
      },
    ];
    setMessages(fresh);
    localStorage.removeItem(STORAGE_KEY);
  };

  const handleCopyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="flex flex-col h-[520px] max-h-[75vh] w-full bg-black/60 rounded-lg border border-cyan-400/40 backdrop-blur-md overflow-hidden text-foreground">
      {/* Terminal Top Control Bar */}
      <div className="flex items-center justify-between px-3.5 py-2.5 bg-cyan-950/40 border-b border-cyan-400/30 text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center h-6 w-6 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_8px_rgba(0,240,255,0.4)]">
            <Sparkles className="h-3.5 w-3.5" />
          </div>
          <div>
            <span className="font-semibold text-cyan-300">Ziggy Neural Terminal</span>
            <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-400/30">
              Gemini 3.8 Flash
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {/* Language Selector */}
          <div className="flex items-center rounded border border-cyan-400/30 bg-black/40 p-0.5 text-[11px]">
            <button
              type="button"
              onClick={() => onSelectLanguage("hi")}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                selectedLanguage === "hi"
                  ? "bg-cyan-500 text-black font-bold"
                  : "text-cyan-300 hover:text-white"
              }`}
            >
              हिन्दी
            </button>
            <button
              type="button"
              onClick={() => onSelectLanguage("en")}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                selectedLanguage === "en"
                  ? "bg-cyan-500 text-black font-bold"
                  : "text-cyan-300 hover:text-white"
              }`}
            >
              EN
            </button>
            <button
              type="button"
              onClick={() => onSelectLanguage("bn")}
              className={`px-1.5 py-0.5 rounded transition-colors ${
                selectedLanguage === "bn"
                  ? "bg-cyan-500 text-black font-bold"
                  : "text-cyan-300 hover:text-white"
              }`}
            >
              বাংলা
            </button>
          </div>

          {/* Clear Memory */}
          <Button
            type="button"
            size="icon"
            variant="ghost"
            onClick={handleClearMemory}
            title="Clear long-term conversation memory"
            className="h-7 w-7 text-muted-foreground hover:text-red-400 hover:bg-red-950/20"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 text-xs leading-relaxed">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex gap-2.5 ${m.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {m.role === "model" && (
              <div className="flex-shrink-0 h-6 w-6 rounded-full bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center text-cyan-300 shadow-[0_0_8px_rgba(0,240,255,0.4)] mt-0.5">
                <Bot className="h-3.5 w-3.5" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-lg p-3 space-y-2 ${
                m.role === "user"
                  ? "bg-cyan-600/30 border border-cyan-400/50 text-cyan-50 shadow-[0_0_12px_rgba(0,240,255,0.2)]"
                  : "bg-black/60 border border-cyan-400/30 text-cyan-100 shadow-[0_0_16px_rgba(4,9,22,0.8)]"
              }`}
            >
              {/* Formatted Message Content */}
              <RenderFormattedText
                content={m.content}
                onCopy={(code) => handleCopyCode(code, m.id)}
                isCopied={copiedId === m.id}
              />

              {/* Action Badge */}
              {m.action && (
                <div className="mt-2 pt-2 border-t border-cyan-400/20 flex items-center justify-between text-[11px] text-amber-300">
                  <span className="flex items-center gap-1">
                    <Zap className="h-3 w-3" /> Action: {m.action.label || m.action.target}
                  </span>
                  <button
                    type="button"
                    onClick={() => m.action && onExecuteAction(m.action)}
                    className="underline hover:text-white"
                  >
                    Execute
                  </button>
                </div>
              )}

              {/* Google Search Grounding Sources */}
              {m.sources && m.sources.length > 0 && (
                <div className="mt-2 pt-2 border-t border-cyan-400/20 space-y-1">
                  <div className="flex items-center gap-1 text-[10px] font-semibold text-cyan-300">
                    <Globe className="h-3 w-3" /> Live Search Grounding Sources:
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {m.sources.map((s, idx) => (
                      <a
                        key={idx}
                        href={s.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] bg-cyan-950/60 border border-cyan-400/40 text-cyan-200 hover:text-white hover:border-cyan-300"
                      >
                        <span className="truncate max-w-[140px]">{s.title}</span>
                        <ExternalLink className="h-2.5 w-2.5 text-cyan-400" />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {m.role === "user" && (
              <div className="flex-shrink-0 h-6 w-6 rounded-full bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-300 mt-0.5">
                <User className="h-3.5 w-3.5" />
              </div>
            )}
          </div>
        ))}

        {loading && (
          <div className="flex items-center gap-2 text-cyan-400 text-xs animate-pulse">
            <Loader2 className="h-4 w-4 animate-spin" />
            <span>Ziggy is thinking with Gemini AI...</span>
          </div>
        )}
      </div>

      {/* Quick Prompt Suggestion Chips */}
      <div className="px-3 py-1.5 bg-black/40 border-t border-cyan-400/20 flex gap-1.5 overflow-x-auto no-scrollbar">
        {QUICK_PROMPTS.map((qp, i) => (
          <button
            key={i}
            type="button"
            disabled={loading}
            onClick={() => handleSendMessage(qp.prompt)}
            className="flex-shrink-0 px-2.5 py-1 rounded-full text-[10px] bg-cyan-950/50 border border-cyan-400/30 text-cyan-300 hover:bg-cyan-500/20 hover:border-cyan-400 transition-colors whitespace-nowrap"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Terminal Input Form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSendMessage(input);
        }}
        className="flex items-center gap-2 p-2.5 bg-black/70 border-t border-cyan-400/30"
      >
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask Ziggy anything (code, crypto, market trends, commands)..."
          disabled={loading}
          className="flex-1 bg-black/60 border-cyan-400/40 text-foreground text-xs h-9 focus-visible:ring-cyan-400"
        />
        <Button
          type="submit"
          size="sm"
          disabled={loading || !input.trim()}
          className="bg-cyan-500 hover:bg-cyan-400 text-black font-bold h-9 px-3.5"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        </Button>
      </form>
    </div>
  );
}

// Lightweight resilient markdown code block & formatted text renderer
function RenderFormattedText({
  content,
  onCopy,
  isCopied,
}: {
  content: string;
  onCopy: (code: string) => void;
  isCopied: boolean;
}) {
  // Split on ```code blocks```
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-2">
      {parts.map((part, idx) => {
        if (part.startsWith("```") && part.endsWith("```")) {
          // Extract language and code body
          const lines = part.slice(3, -3).split("\n");
          const firstLine = lines[0]?.trim() || "";
          const hasLang = /^[a-zA-Z0-9_-]+$/.test(firstLine);
          const lang = hasLang ? firstLine : "code";
          const code = (hasLang ? lines.slice(1) : lines).join("\n").trim();

          return (
            <div
              key={idx}
              className="my-2 rounded border border-cyan-400/40 bg-black/80 overflow-hidden text-[11px]"
            >
              <div className="flex items-center justify-between px-2.5 py-1 bg-cyan-950/60 border-b border-cyan-400/30 text-[10px] text-cyan-300">
                <span className="flex items-center gap-1 font-mono uppercase">
                  <Code className="h-3 w-3" /> {lang}
                </span>
                <button
                  type="button"
                  onClick={() => onCopy(code)}
                  className="flex items-center gap-1 hover:text-white transition-colors"
                >
                  {isCopied ? (
                    <Check className="h-3 w-3 text-green-400" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                  <span>{isCopied ? "Copied" : "Copy"}</span>
                </button>
              </div>
              <pre className="p-3 overflow-x-auto font-mono text-cyan-100 selection:bg-cyan-500/30">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // Standard text with bold formatting
        return (
          <p key={idx} className="whitespace-pre-wrap leading-relaxed">
            {part.split(/(\*\*.*?\*\*)/g).map((sub, sIdx) => {
              if (sub.startsWith("**") && sub.endsWith("**")) {
                return (
                  <strong key={sIdx} className="font-bold text-cyan-300">
                    {sub.slice(2, -2)}
                  </strong>
                );
              }
              return sub;
            })}
          </p>
        );
      })}
    </div>
  );
}
