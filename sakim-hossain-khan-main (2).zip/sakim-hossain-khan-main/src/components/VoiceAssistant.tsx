import { Mic, MicOff, PhoneOff, Volume2, X } from "lucide-react";
import { useLiveVoice } from "@/hooks/use-live-voice";

const LABELS: Record<string, string> = {
  idle: "Tap to start talking",
  closed: "Tap to start talking",
  connecting: "Connecting…",
  connected: "Listening — speak any language",
  stopping: "Ending…",
};

export function VoiceAssistant({ open, onClose }: { open: boolean; onClose: () => void }) {
  const voice = useLiveVoice({});
  const idle = voice.status === "idle" || voice.status === "closed";
  const live = voice.status === "connected";

  const close = () => {
    if (!idle) voice.stop();
    onClose();
  };

  return (
    <div
      className={`fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur ${open ? "" : "hidden"}`}
      role="dialog"
      aria-label="SAKIM AI Voice Assistant"
    >
      <div className="glass relative w-full max-w-sm p-6 text-center">
        <button
          onClick={close}
          aria-label="Close"
          className="absolute right-3 top-3 text-muted-foreground hover:text-primary"
        >
          <X className="h-5 w-5" />
        </button>
        <p className="font-display text-xs tracking-[0.3em] text-muted-foreground">
          SAKIM AI · VOICE
        </p>

        <button
          onClick={idle ? voice.start : undefined}
          disabled={!idle}
          aria-label={idle ? "Start voice conversation" : "Voice conversation active"}
          className="relative mx-auto my-8 grid h-40 w-40 place-items-center"
        >
          <span
            className={`absolute inset-0 rounded-full border-2 border-dashed border-primary/50 ${live ? "animate-spin-slow" : ""}`}
          />
          <span
            className={`absolute inset-4 rounded-full border border-accent/50 shadow-[var(--shadow-neon)] ${live && !voice.muted ? "animate-pulse" : ""}`}
          />
          <span className="btn-neon relative grid h-20 w-20 place-items-center rounded-full!">
            {voice.muted ? <MicOff className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
          </span>
        </button>

        <p role="status" className="font-semibold text-primary">
          {voice.muted && live ? "Microphone muted" : (LABELS[voice.status] ?? voice.status)}
        </p>
        <p className="mt-1 text-xs text-muted-foreground">हिन्दी, English & more</p>
        {voice.error && (
          <p role="alert" className="mt-3 text-sm text-destructive">
            {voice.error}
          </p>
        )}

        <div className="mt-6 flex justify-center gap-3">
          <button
            disabled={!live}
            onClick={() => voice.setMuted(!voice.muted)}
            className="glass flex items-center gap-2 px-4 py-2 text-sm font-semibold hover:text-primary disabled:opacity-40"
          >
            {voice.muted ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
            {voice.muted ? "Unmute" : "Mute"}
          </button>
          <button
            disabled={idle || voice.status === "stopping"}
            onClick={voice.stop}
            className="glass flex items-center gap-2 px-4 py-2 text-sm font-semibold text-destructive disabled:opacity-40"
          >
            <PhoneOff className="h-4 w-4" /> End
          </button>
        </div>
        {voice.playbackBlocked && (
          <button
            onClick={voice.resumePlayback}
            className="btn-neon mt-4 inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-bold"
          >
            <Volume2 className="h-4 w-4" /> Play voice
          </button>
        )}
        <audio ref={voice.audioRef} className="sr-only" />
        <p className="mt-5 text-[11px] text-muted-foreground">
          Never share keys or seed phrases. Not financial advice.
        </p>
      </div>
    </div>
  );
}
