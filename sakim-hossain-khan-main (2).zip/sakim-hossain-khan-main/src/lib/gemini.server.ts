import { GoogleGenAI } from "@google/genai";

export interface ChatMessage {
  role: "user" | "model";
  content: string;
}

export interface GeminiChatPayload {
  message: string;
  history?: ChatMessage[];
  language?: "en" | "hi" | "bn";
  enableSearch?: boolean;
}

export interface GeminiChatResponse {
  reply: string;
  action?: {
    type: "open_url" | "navigate" | "search" | "open_panel";
    target?: string;
    label?: string;
  };
  sources?: Array<{ title: string; url: string }>;
  error?: string;
}

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;

  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

const SYSTEM_INSTRUCTION = `You are ZIGGY, a brilliant futuristic personal AI Assistant developed for the SAKIM AI ecosystem.
You are powered by Google Gemini AI.
You have a friendly, confident, cyberpunk yet warm and intelligent personality (like Jarvis meets ChatGPT).

KEY CAPABILITIES:
1. Multi-Language Fluency:
   - You natively speak English, Hindi (हिन्दी / Hinglish), and Bengali (বাংলা / Banglish).
   - Match the user's language or answer in their requested language naturally.
2. Coding & Technical Problem Solving:
   - You are a senior software engineer and blockchain architect.
   - When asked to write code (TypeScript, Python, Solidity, React, HTML, etc.), provide clean, well-structured, production-ready code with concise explanations.
   - You assist with the SAKIM Token Builder, smart contracts, tokenomics, and launchpad roadmap.
3. Web & Real-Time Intelligence:
   - You search the web in real-time when the user asks for current news, prices, weather, or recent facts.
4. Action Execution:
   - You can execute commands. When the user asks you to open a website, search the web, or navigate the SAKIM app, perform the action by including an ACTION tag at the very end of your response in this exact format:
     [ACTION:{"type":"open_url","target":"https://www.youtube.com","label":"Opening YouTube"}]
     [ACTION:{"type":"open_url","target":"https://mail.google.com","label":"Opening Gmail"}]
     [ACTION:{"type":"open_url","target":"https://calendar.google.com","label":"Opening Google Calendar"}]
     [ACTION:{"type":"open_url","target":"https://drive.google.com","label":"Opening Google Drive"}]
     [ACTION:{"type":"navigate","target":"/create","label":"Opening Token Builder"}]
     [ACTION:{"type":"navigate","target":"/tokens","label":"Opening My Tokens"}]
     [ACTION:{"type":"navigate","target":"/launchpad","label":"Opening Launchpad"}]
     [ACTION:{"type":"search","target":"query terms","label":"Searching Google"}]
     [ACTION:{"type":"open_panel","target":"pc","label":"Opening PC Control Notice"}]
5. Tone:
   - Keep conversational voice responses concise (1-3 sentences) when spoken, but provide comprehensive, well-formatted answers with markdown code blocks when in text chat or solving complex problems.`;

export async function processGeminiChat(payload: GeminiChatPayload): Promise<GeminiChatResponse> {
  const { message, history = [], language = "en", enableSearch = true } = payload;
  const userText = message.trim();

  if (!userText) {
    return { reply: "Please provide a question or command." };
  }

  const ai = getGeminiClient();

  // If Gemini API Key is missing on the server, gracefully fallback to intelligent local reasoning
  if (!ai) {
    return fallbackResponse(userText, language);
  }

  try {
    // Format conversation history for Gemini multi-turn format
    const contents: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }> = [];

    // Include recent history (last 10 turns for memory)
    for (const msg of history.slice(-10)) {
      if (msg.content) {
        contents.push({
          role: msg.role === "user" ? "user" : "model",
          parts: [{ text: msg.content }],
        });
      }
    }

    // Add current user prompt
    contents.push({
      role: "user",
      parts: [
        {
          text: `[User Preferred Language: ${language === "hi" ? "Hindi" : language === "bn" ? "Bengali" : "English"}]\n${userText}`,
        },
      ],
    });

    // Call Gemini 3.8 Flash model
    const config: Record<string, unknown> = {
      systemInstruction: SYSTEM_INSTRUCTION,
    };

    if (enableSearch) {
      config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents,
      config,
    });

    let rawText = response.text ?? "";

    // Extract citations from Search Grounding
    const sources: Array<{ title: string; url: string }> = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (Array.isArray(chunks)) {
      for (const chunk of chunks) {
        const web = (chunk as { web?: { uri?: string; title?: string } }).web;
        if (web?.uri) {
          sources.push({
            title: web.title || new URL(web.uri).hostname,
            url: web.uri,
          });
        }
      }
    }

    // Extract [ACTION:{...}] tag if present
    let action: GeminiChatResponse["action"] = undefined;
    const actionMatch = rawText.match(/\[ACTION:(\{.*?\})\]/s);
    if (actionMatch && actionMatch[1]) {
      try {
        action = JSON.parse(actionMatch[1]);
        rawText = rawText.replace(actionMatch[0], "").trim();
      } catch {
        // ignore parse error
      }
    }

    // Auto-detect commands if Gemini did not include an explicit action tag
    if (!action) {
      action = detectImplicitAction(userText);
    }

    return {
      reply: rawText.trim() || "I processed your request.",
      action,
      sources: sources.length > 0 ? sources.slice(0, 5) : undefined,
    };
  } catch (error) {
    console.error("Gemini AI API Error:", error);

    // Provide friendly, non-crashing response on rate limit or API error
    const errMessage = error instanceof Error ? error.message : String(error);
    if (errMessage.includes("429") || errMessage.includes("RESOURCE_EXHAUSTED")) {
      return {
        reply:
          language === "hi"
            ? "जेमिनी एआई कोटा सीमा पर है। मैं आपकी कमांड निष्पादित कर रहा हूँ।"
            : language === "bn"
              ? "জেমিনি এআই কোটা পূর্ণ হয়েছে। আমি আপনার কমান্ড নির্বাহ করছি।"
              : "Gemini AI is processing at peak capacity. Executing your command directly.",
        action: detectImplicitAction(userText),
      };
    }

    return fallbackResponse(userText, language);
  }
}

function detectImplicitAction(text: string): GeminiChatResponse["action"] | undefined {
  const lower = text.toLowerCase();
  if (lower.includes("youtube")) {
    return { type: "open_url", target: "https://www.youtube.com", label: "Opening YouTube" };
  }
  if (lower.includes("gmail") || lower.includes("email") || lower.includes("inbox")) {
    return { type: "open_url", target: "https://mail.google.com", label: "Opening Gmail" };
  }
  if (lower.includes("calendar")) {
    return {
      type: "open_url",
      target: "https://calendar.google.com",
      label: "Opening Google Calendar",
    };
  }
  if (lower.includes("google drive") || lower.includes("drive")) {
    return { type: "open_url", target: "https://drive.google.com", label: "Opening Google Drive" };
  }
  if (lower.includes("create token") || lower.includes("token builder")) {
    return { type: "navigate", target: "/create", label: "Opening Token Builder" };
  }
  if (lower.includes("my tokens") || lower.includes("view tokens")) {
    return { type: "navigate", target: "/tokens", label: "Opening My Tokens" };
  }
  if (lower.includes("launchpad")) {
    return { type: "navigate", target: "/launchpad", label: "Opening Launchpad" };
  }
  if (lower.startsWith("search ") || lower.startsWith("google ") || lower.startsWith("find ")) {
    const q = text.replace(/^(search|google|find)\s+/i, "").trim();
    return { type: "search", target: q, label: `Searching Google for "${q}"` };
  }
  if (lower.includes("pc control") || lower.includes("control my computer")) {
    return { type: "open_panel", target: "pc", label: "Checking PC Control" };
  }
  return undefined;
}

function fallbackResponse(text: string, language: "en" | "hi" | "bn"): GeminiChatResponse {
  const action = detectImplicitAction(text);
  const lower = text.toLowerCase();

  if (action) {
    return {
      reply:
        language === "hi"
          ? `मैंने आपकी कमांड स्वीकार कर ली है: ${action.label}`
          : language === "bn"
            ? `আমি আপনার কমান্ড পেয়েছি: ${action.label}`
            : `Executing action: ${action.label}`,
      action,
    };
  }

  if (lower.includes("hello") || lower.includes("hi") || lower.includes("namaste")) {
    return {
      reply:
        language === "hi"
          ? "नमस्ते! मैं ज़िग्गी हूँ, साकिम का एआई असिस्टेंट। मैं आपकी क्या मदद कर सकता हूँ?"
          : language === "bn"
            ? "নমস্কার! আমি জিগি, সাকিম এআই সহকারী। আমি আপনাকে কীভাবে সাহায্য করতে পারি?"
            : "Hello! I am Ziggy, your Sakim AI Assistant powered by Google Gemini. How can I assist you today?",
    };
  }

  if (lower.includes("who are you") || lower.includes("your name")) {
    return {
      reply:
        language === "hi"
          ? "मैं ज़िग्गी हूँ, गूगल जेमिनी एआई द्वारा संचालित आपका स्मार्ट पर्सनल असिस्टेंट।"
          : language === "bn"
            ? "আমি জিগি, গুগল জেমিনি এআই চালিত আপনার স্মার্ট ব্যক্তিগত সহকারী।"
            : "I am Ziggy, your smart personal AI assistant powered by Google Gemini. I can write code, search the web, execute commands, and help build crypto projects.",
    };
  }

  return {
    reply:
      language === "hi"
        ? `मैंने आपका अनुरोध समझ लिया है: "${text}". आप वेब सर्च, ऐप्स या टोकन बिल्डर आज़मा सकते हैं।`
        : language === "bn"
          ? `আমি আপনার অনুরোধটি পেয়েছি: "${text}". আপনি ওয়েব সার্চ, অ্যাপস বা টোকেন বিল্ডার চেষ্টা করতে পারেন।`
          : `I received your prompt: "${text}". I can write code, search Google, launch apps, or guide you in the SAKIM Token Builder.`,
  };
}
