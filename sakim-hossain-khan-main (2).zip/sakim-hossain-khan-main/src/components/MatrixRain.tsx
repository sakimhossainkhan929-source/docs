import { useEffect, useRef } from "react";

interface MatrixRainProps {
  className?: string;
  opacity?: number;
}

// Pure digital numbers: 0-9, binary, and numeric sequences (strictly no static digits or punctuation)
const CHAR_SET = [
  "0",
  "1",
  "2",
  "3",
  "4",
  "5",
  "6",
  "7",
  "8",
  "9",
  "0",
  "1",
  "7",
  "3",
  "8",
  "5",
  "9",
  "2",
  "4",
  "6",
  "1",
  "0",
];

export function MatrixRain({ className = "", opacity = 0.35 }: MatrixRainProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId = 0;
    let lastTime = 0;
    const fps = 32;
    const interval = 1000 / fps;

    // Check reduced motion
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReducedMotion) {
      // Just render a static subtle digital backdrop
      ctx.fillStyle = "rgba(5, 12, 28, 0.9)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      return;
    }

    const fontSize = 14;
    let columns = 0;
    let drops: number[] = [];
    let speeds: number[] = [];
    let colors: string[] = [];

    const initGrid = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const width = canvas.parentElement?.clientWidth || window.innerWidth;
      const height = canvas.parentElement?.clientHeight || window.innerHeight;

      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.scale(dpr, dpr);

      columns = Math.floor(width / (fontSize * 1.2));
      drops = [];
      speeds = [];
      colors = [];

      for (let i = 0; i < columns; i++) {
        // Random starting positions staggered vertically
        drops[i] = Math.floor(Math.random() * -50);
        speeds[i] = 0.5 + Math.random() * 0.8;
        // Glowing cyan (#00f0ff) and golden highlights (#ffd05b)
        const rand = Math.random();
        if (rand < 0.32) {
          colors[i] = "#ffd05b"; // Rich glowing gold
        } else if (rand < 0.72) {
          colors[i] = "#00f0ff"; // Radiant neon cyan
        } else {
          colors[i] = "#38bdf8"; // Sky cyan glow
        }
      }
    };

    initGrid();

    const resizeObserver = new ResizeObserver(() => {
      initGrid();
    });

    if (canvas.parentElement) {
      resizeObserver.observe(canvas.parentElement);
    }

    const draw = (currentTime: number) => {
      animationFrameId = requestAnimationFrame(draw);

      if (document.hidden) return;

      const delta = currentTime - lastTime;
      if (delta < interval) return;
      lastTime = currentTime - (delta % interval);

      const width =
        canvas.width / (window.devicePixelRatio > 1 ? Math.min(window.devicePixelRatio, 1.5) : 1);
      const height =
        canvas.height / (window.devicePixelRatio > 1 ? Math.min(window.devicePixelRatio, 1.5) : 1);

      // Translucent navy fade to create smooth phosphor trails
      ctx.fillStyle = "rgba(3, 8, 22, 0.20)";
      ctx.fillRect(0, 0, width, height);

      ctx.font = `700 ${fontSize}px "Courier New", monospace`;

      for (let i = 0; i < drops.length; i++) {
        // Continuously cycle characters so no digit remains static
        const char = CHAR_SET[Math.floor(Math.random() * CHAR_SET.length)] ?? "0";
        const x = i * fontSize * 1.2;
        const currentDrop = drops[i] ?? 0;
        const y = currentDrop * fontSize;

        const baseColor = colors[i] || "#00f0ff";
        const isGold = baseColor === "#ffd05b";

        // Head falling digit is glowing luminous white-cyan or white-gold
        if (Math.random() > 0.82) {
          ctx.fillStyle = isGold ? "#fff6cc" : "#e0f9ff";
          ctx.shadowBlur = 12;
          ctx.shadowColor = baseColor;
        } else {
          ctx.fillStyle = baseColor;
          ctx.shadowBlur = 6;
          ctx.shadowColor = baseColor;
        }

        ctx.fillText(char, x, y);

        // Reset shadow
        ctx.shadowBlur = 0;

        // Reset drop to top with randomized delay once it leaves screen
        if (y > height && Math.random() > 0.975) {
          drops[i] = 0;
          speeds[i] = 0.5 + Math.random() * 0.8;
          const rand = Math.random();
          colors[i] = rand < 0.32 ? "#ffd05b" : rand < 0.72 ? "#00f0ff" : "#38bdf8";
        }

        drops[i] = currentDrop + (speeds[i] ?? 0.6);
      }
    };

    animationFrameId = requestAnimationFrame(draw);

    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className={`pointer-events-none absolute inset-0 h-full w-full ${className}`}
      style={{ opacity }}
      aria-hidden="true"
    />
  );
}
