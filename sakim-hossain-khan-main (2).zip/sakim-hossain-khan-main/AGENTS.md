<!-- LOVABLE:BEGIN -->

> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

<!-- LOVABLE:END -->

- Voice assistant runs through a persistent WebSocket relay at /api/live (src/lib/live-relay.server.ts, dispatched in src/server.ts and live-vite-plugin.ts in dev); keeps the AI key server-only and the call open for the whole session.
- Keep dashboard presentation in AIDashboard and its client-created Three.js HologramScene; reuse the existing voice hook and scope theme overrides to the dashboard so crypto systems remain unchanged.
- Browser dashboard tools open validated HTTP destinations or existing workspace routes; never simulate desktop privileges or claim native app control without an authorized companion.
