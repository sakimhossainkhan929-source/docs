export type PreviewToken = {
  id: string;
  name: string;
  symbol: string;
  supply: number;
  logo?: string | undefined;
  createdAt: string;
  status?: "preview" | "deployed";
  contractAddress?: string;
  deploymentTxHash?: string;
  network?: string;
  serviceFeePaidUsd?: number;
  gasFeePaidUsd?: number;
  totalPaidUsd?: number;
  explorerUrl?: string;
};

const KEY = "sakim-preview-tokens";

export function validateToken(name: string, symbol: string, supply: string): string | null {
  if (name.trim().length < 2 || name.trim().length > 40) return "Name must be 2–40 characters.";
  if (!/^[A-Z0-9]{2,10}$/.test(symbol.trim().toUpperCase()))
    return "Symbol must be 2–10 letters or numbers.";
  const n = Number(supply);
  if (!Number.isInteger(n) || n < 1 || n > 1e15)
    return "Supply must be a whole number from 1 to 1,000,000,000,000,000.";
  return null;
}

export function loadTokens(): PreviewToken[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveToken(t: PreviewToken) {
  localStorage.setItem(KEY, JSON.stringify([t, ...loadTokens()]));
}

export function removeToken(id: string) {
  localStorage.setItem(KEY, JSON.stringify(loadTokens().filter((t) => t.id !== id)));
}
