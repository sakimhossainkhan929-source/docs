import { useSyncExternalStore } from "react";

export type Eip1193Provider = {
  request: (args: { method: string; params?: unknown[] | object }) => Promise<unknown>;
  on?: (event: string, handler: (...args: unknown[]) => void) => void;
  removeListener?: (event: string, handler: (...args: unknown[]) => void) => void;
  isMetaMask?: boolean;
  providers?: Eip1193Provider[];
};

export type WalletState = {
  address: string | null;
  chainId: string | null;
  balance: string | null;
  isMetaMask: boolean;
  isInstalled: boolean;
};

export const BSC_MAINNET_CHAIN_ID = "0x38"; // 56 in decimal
export const BSC_TESTNET_CHAIN_ID = "0x61"; // 97 in decimal

export const BSC_NETWORKS = {
  mainnet: {
    chainId: BSC_MAINNET_CHAIN_ID,
    decimalChainId: 56,
    chainName: "BNB Smart Chain Mainnet",
    nativeCurrency: {
      name: "BNB",
      symbol: "BNB",
      decimals: 18,
    },
    rpcUrls: ["https://bsc-dataseed.binance.org/", "https://bsc-dataseed1.defibit.io/"],
    blockExplorerUrls: ["https://bscscan.com/"],
  },
  testnet: {
    chainId: BSC_TESTNET_CHAIN_ID,
    decimalChainId: 97,
    chainName: "BNB Smart Chain Testnet",
    nativeCurrency: {
      name: "tBNB",
      symbol: "tBNB",
      decimals: 18,
    },
    rpcUrls: ["https://data-seed-prebsc-1-s1.binance.org:8545/"],
    blockExplorerUrls: ["https://testnet.bscscan.com/"],
  },
} as const;

const STORAGE_KEY = "sakim-wallet-address";
const EMPTY: WalletState = {
  address: null,
  chainId: null,
  balance: null,
  isMetaMask: false,
  isInstalled: false,
};

const CHAINS: Record<string, string> = {
  "0x38": "BNB Smart Chain",
  "0x61": "BNB Testnet",
  "0x1": "Ethereum Mainnet",
  "0x5": "Goerli",
  "0xa": "OP Mainnet",
  "0x89": "Polygon",
  "0xa4b1": "Arbitrum One",
  "0xaa36a7": "Sepolia",
  "0x13882": "Polygon Amoy",
};

let state: WalletState = EMPTY;
let initialized = false;
const listeners = new Set<() => void>();

function emit() {
  for (const l of listeners) l();
}

function setState(patch: Partial<WalletState>) {
  state = { ...state, ...patch };
  emit();
}

export function getProvider(): Eip1193Provider | null {
  if (typeof window === "undefined") return null;
  const eth = (window as unknown as { ethereum?: Eip1193Provider }).ethereum;
  if (!eth) return null;

  // Check if multiple providers exist (e.g., MetaMask + Phantom + Coinbase)
  if (Array.isArray(eth.providers) && eth.providers.length > 0) {
    const mm = eth.providers.find((p) => p?.isMetaMask);
    if (mm) return mm;
    return eth.providers[0] ?? null;
  }

  return eth;
}

export function hasWalletProvider(): boolean {
  return getProvider() !== null;
}

export function isMetaMaskProvider(): boolean {
  const p = getProvider();
  return Boolean(p?.isMetaMask);
}

export function isMobileBrowser(): boolean {
  if (typeof window === "undefined" || !navigator.userAgent) return false;
  return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

export function getMetaMaskMobileDeepLink(customUrl?: string): string {
  if (typeof window === "undefined") return "https://metamask.app.link/dapp/sakim.ai";
  const target = customUrl || `${window.location.host}${window.location.pathname}`;
  const cleanTarget = target.replace(/^https?:\/\//, "");
  return `https://metamask.app.link/dapp/${cleanTarget}`;
}

export function shortAddress(address: string): string {
  return address.length > 13 ? `${address.slice(0, 6)}…${address.slice(-4)}` : address;
}

export function chainName(chainId: string | null): string {
  if (!chainId) return "";
  const known = CHAINS[chainId.toLowerCase()];
  if (known) return known;
  const n = parseInt(chainId, 16);
  return Number.isNaN(n) ? "" : `Chain ${n}`;
}

export function isBscChain(chainId: string | null): boolean {
  if (!chainId) return false;
  const lower = chainId.toLowerCase();
  return lower === BSC_MAINNET_CHAIN_ID || lower === BSC_TESTNET_CHAIN_ID || lower === "0x38" || lower === "0x61";
}

export function formatBalance(hexWei: string | null, chainId?: string | null): string | null {
  if (!hexWei) return null;
  try {
    const bnbVal = Number(BigInt(hexWei)) / 1e18;
    const isTestnet = chainId?.toLowerCase() === BSC_TESTNET_CHAIN_ID;
    const sym = isTestnet ? "tBNB" : "BNB";
    return `${bnbVal.toFixed(4)} ${sym}`;
  } catch {
    return null;
  }
}

export async function refreshDetails() {
  const provider = getProvider();
  const { address } = state;
  if (!provider || !address) return;
  try {
    const [hexWei, chainId] = (await Promise.all([
      provider.request({ method: "eth_getBalance", params: [address, "latest"] }),
      provider.request({ method: "eth_chainId" }),
    ])) as [string, string];
    if (state.address !== address) return;
    setState({
      balance: formatBalance(hexWei, chainId),
      chainId: chainId ?? null,
      isInstalled: true,
      isMetaMask: Boolean(provider.isMetaMask),
    });
  } catch {
    // balance/chain are display-only
  }
}

function init() {
  if (initialized || typeof window === "undefined") return;
  initialized = true;

  const provider = getProvider();
  const isInstalled = Boolean(provider);
  const isMetaMask = Boolean(provider?.isMetaMask);
  state = { ...state, isInstalled, isMetaMask };

  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved && provider) {
    state = { ...state, address: saved, isInstalled, isMetaMask };
    void refreshDetails();
  }

  provider?.on?.("accountsChanged", (accounts) => {
    const list = accounts as string[] | undefined;
    const address = list?.[0] ?? null;
    if (address) {
      localStorage.setItem(STORAGE_KEY, address);
      setState({ address, balance: null });
      void refreshDetails();
    } else {
      localStorage.removeItem(STORAGE_KEY);
      state = { ...EMPTY, isInstalled, isMetaMask };
      emit();
    }
  });

  provider?.on?.("chainChanged", (chainId) => {
    setState({ chainId: (chainId as string) ?? null, balance: null });
    void refreshDetails();
  });
}

function subscribe(cb: () => void) {
  init();
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}

const getSnapshot = () => state;
const getServerSnapshot = () => EMPTY;

export function useWallet(): WalletState {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

export type ConnectResult = { ok: true; address: string } | { ok: false; error: string };

export async function connectWallet(): Promise<ConnectResult> {
  const provider = getProvider();
  if (!provider) {
    if (isMobileBrowser()) {
      return {
        ok: false,
        error: "MetaMask not detected in browser. Use the 'Open in MetaMask Mobile App' option.",
      };
    }
    return {
      ok: false,
      error: "MetaMask extension not found. Please install MetaMask from metamask.io.",
    };
  }

  try {
    const accounts = (await provider.request({ method: "eth_requestAccounts" })) as string[];
    const address = accounts?.[0];
    if (!address) {
      return { ok: false, error: "No account selected. Please unlock MetaMask and choose an account." };
    }
    localStorage.setItem(STORAGE_KEY, address);
    setState({
      address,
      isInstalled: true,
      isMetaMask: Boolean(provider.isMetaMask),
    });
    void refreshDetails();
    return { ok: true, address };
  } catch (err: unknown) {
    const code = (err as { code?: number })?.code;
    const message = (err as { message?: string })?.message || "";
    if (code === 4001 || message.includes("User rejected")) {
      return { ok: false, error: "Connection request was rejected in MetaMask." };
    }
    if (code === -32002) {
      return {
        ok: false,
        error: "MetaMask is already waiting for your approval. Please open the MetaMask extension popup.",
      };
    }
    return { ok: false, error: message || "Could not connect to MetaMask. Please try again." };
  }
}

export async function switchToBsc(network: "mainnet" | "testnet" = "mainnet"): Promise<{ ok: boolean; error?: string }> {
  const provider = getProvider();
  if (!provider) {
    return { ok: false, error: "MetaMask is not available to switch networks." };
  }

  const targetConfig = BSC_NETWORKS[network];

  try {
    await provider.request({
      method: "wallet_switchEthereumChain",
      params: [{ chainId: targetConfig.chainId }],
    });
    void refreshDetails();
    return { ok: true };
  } catch (switchError: unknown) {
    const errCode = (switchError as { code?: number })?.code;
    // Code 4902 means the chain has not been added to MetaMask yet
    if (errCode === 4902 || (switchError as { message?: string })?.message?.includes("Unrecognized chain ID")) {
      try {
        await provider.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: targetConfig.chainId,
              chainName: targetConfig.chainName,
              nativeCurrency: targetConfig.nativeCurrency,
              rpcUrls: targetConfig.rpcUrls,
              blockExplorerUrls: targetConfig.blockExplorerUrls,
            },
          ],
        });
        void refreshDetails();
        return { ok: true };
      } catch (addError: unknown) {
        const addCode = (addError as { code?: number })?.code;
        if (addCode === 4001) {
          return { ok: false, error: "Adding BNB Smart Chain was rejected in MetaMask." };
        }
        return { ok: false, error: "Failed to add BNB Smart Chain to MetaMask." };
      }
    }

    if (errCode === 4001) {
      return { ok: false, error: "Switching to BNB Smart Chain was rejected in MetaMask." };
    }

    return {
      ok: false,
      error: (switchError as { message?: string })?.message || "Failed to switch to BNB Smart Chain.",
    };
  }
}

export function disconnectWallet() {
  if (typeof window !== "undefined") localStorage.removeItem(STORAGE_KEY);
  state = { ...EMPTY, isInstalled: Boolean(getProvider()), isMetaMask: Boolean(getProvider()?.isMetaMask) };
  emit();
}
