import { useState } from "react";
import { toast } from "sonner";
import {
  AlertTriangle,
  ArrowRight,
  Check,
  Copy,
  ExternalLink,
  HelpCircle,
  Loader2,
  Lock,
  LogOut,
  Network,
  RefreshCw,
  Shield,
  Smartphone,
  Wallet,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  BSC_MAINNET_CHAIN_ID,
  BSC_TESTNET_CHAIN_ID,
  chainName,
  connectWallet,
  disconnectWallet,
  getMetaMaskMobileDeepLink,
  hasWalletProvider,
  isBscChain,
  isMobileBrowser,
  shortAddress,
  switchToBsc,
  useWallet,
} from "@/lib/wallet";

interface WalletModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function WalletModal({ open, onOpenChange }: WalletModalProps) {
  const wallet = useWallet();
  const [connecting, setConnecting] = useState(false);
  const [switchingNetwork, setSwitchingNetwork] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [showGuide, setShowGuide] = useState(false);

  const isConnected = Boolean(wallet.address);
  const isInstalled = hasWalletProvider();
  const isMobile = isMobileBrowser();
  const isBsc = isBscChain(wallet.chainId);
  const isTestnet = wallet.chainId?.toLowerCase() === BSC_TESTNET_CHAIN_ID;

  const handleConnect = async () => {
    setConnecting(true);
    try {
      const res = await connectWallet();
      if (res.ok) {
        toast.success("Wallet Connected", {
          description: `Connected to ${shortAddress(res.address)}`,
        });
        onOpenChange(false);
      } else {
        toast.error("Connection Failed", { description: res.error });
      }
    } finally {
      setConnecting(false);
    }
  };

  const handleSwitchNetwork = async (target: "mainnet" | "testnet") => {
    setSwitchingNetwork(target);
    try {
      const res = await switchToBsc(target);
      if (res.ok) {
        toast.success(`Switched to BNB Smart Chain ${target === "testnet" ? "Testnet" : "Mainnet"}`);
      } else {
        toast.error("Network Switch Failed", { description: res.error });
      }
    } finally {
      setSwitchingNetwork(null);
    }
  };

  const copyAddress = () => {
    if (!wallet.address) return;
    navigator.clipboard.writeText(wallet.address);
    setCopied(true);
    toast.success("Address copied to clipboard!");
    setTimeout(() => setCopied(false), 2000);
  };

  const explorerBase = isTestnet ? "https://testnet.bscscan.com" : "https://bscscan.com";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sakim-hud-dialog sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#e2761b]/15 p-1 border border-[#e2761b]/40 shadow-[0_0_12px_rgba(226,118,27,0.3)]">
              {/* Fox icon */}
              <svg viewBox="0 0 32 32" className="h-6 w-6" aria-hidden="true">
                <path
                  fill="#e2761b"
                  d="m28.6 4.7-10.2 7.6 1.9-4.5zM3.4 4.7l10.1 7.6-1.8-4.5zM24.7 21.8l-2.7 4.1 5.9 1.6 1.7-5.6zM7.3 21.8l-4.9.1 1.7 5.6 5.9-1.6z"
                />
                <path
                  fill="#e4761b"
                  d="m8.7 13.9-1.6 2.4 5.7.3-.2-6.2zM23.3 13.9l-3.9-3.5-.2 6.2 5.7-.3zM10 25.9l3.4-1.7-3-2.3zM22 25.9l-.4-4-3 2.3z"
                />
                <path
                  fill="#d7c1b3"
                  d="m18.6 24.2 3-2.3-.4-4-5.2-.4.4 3.7zM10.4 21.9l3 2.3 2.2-3-.4-3.7-5.2.4z"
                />
                <path
                  fill="#233447"
                  d="m10.8 17.9 4.8-.4-.4-3.7-4.4.2zM21.2 17.9l.4-3.9-4.4-.2-.4 3.7z"
                />
              </svg>
            </div>
            <div>
              <DialogTitle className="font-display text-cyan-300 drop-shadow-[0_0_8px_rgba(0,240,255,0.6)]">
                {isConnected ? "MetaMask Wallet Connected" : "Connect MetaMask Wallet"}
              </DialogTitle>
              <DialogDescription className="text-muted-foreground text-xs">
                BNB Smart Chain (BEP-20) Web3 Integration
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {isConnected ? (
          /* STATE 1: WALLET CONNECTED */
          <div className="space-y-4 pt-2">
            {/* Wallet Info Card */}
            <div className="rounded-xl border border-cyan-400/40 bg-black/60 p-4 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Connected Address</span>
                <button
                  type="button"
                  onClick={copyAddress}
                  className="flex items-center gap-1 text-cyan-400 hover:text-white transition-colors"
                >
                  {copied ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
              </div>

              <div className="flex items-center justify-between">
                <span className="font-mono text-sm font-bold text-foreground break-all select-all">
                  {wallet.address}
                </span>
              </div>

              <div className="border-t border-cyan-400/20 pt-2.5 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Balance:</span>
                <span className="font-mono font-bold text-amber-300">
                  {wallet.balance || "Loading balance..."}
                </span>
              </div>
            </div>

            {/* Network Status & Switcher */}
            <div className="rounded-xl border border-cyan-400/30 bg-cyan-950/20 p-3.5 space-y-2.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-muted-foreground">
                  <Network className="h-3.5 w-3.5 text-cyan-400" /> Current Network:
                </span>
                <span
                  className={`px-2 py-0.5 rounded text-[11px] font-bold border ${
                    isBsc
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-400/50"
                      : "bg-amber-500/20 text-amber-300 border-amber-400/50"
                  }`}
                >
                  {chainName(wallet.chainId) || "Unknown Network"}
                </span>
              </div>

              {!isBsc && (
                <div className="flex items-center gap-1.5 text-amber-300 text-[11px] bg-amber-950/40 p-2 rounded border border-amber-400/30">
                  <AlertTriangle className="h-3.5 w-3.5 shrink-0 text-amber-400" />
                  <span>Please switch to BNB Smart Chain to deploy tokens and execute transactions.</span>
                </div>
              )}

              {/* Quick Network Switch Buttons */}
              <div className="grid grid-cols-2 gap-2 pt-1">
                <button
                  type="button"
                  disabled={Boolean(switchingNetwork) || wallet.chainId?.toLowerCase() === BSC_MAINNET_CHAIN_ID}
                  onClick={() => handleSwitchNetwork("mainnet")}
                  className={`py-2 px-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                    wallet.chainId?.toLowerCase() === BSC_MAINNET_CHAIN_ID
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-400 cursor-default"
                      : "bg-black/60 text-cyan-200 border-cyan-400/40 hover:bg-cyan-500/10 hover:border-cyan-400"
                  }`}
                >
                  {switchingNetwork === "mainnet" ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <RefreshCw className="h-3 w-3" />
                  )}
                  <span>BSC Mainnet (56)</span>
                </button>

                <button
                  type="button"
                  disabled={Boolean(switchingNetwork) || wallet.chainId?.toLowerCase() === BSC_TESTNET_CHAIN_ID}
                  onClick={() => handleSwitchNetwork("testnet")}
                  className={`py-2 px-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                    wallet.chainId?.toLowerCase() === BSC_TESTNET_CHAIN_ID
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-400 cursor-default"
                      : "bg-black/60 text-amber-200 border-amber-400/40 hover:bg-amber-500/10 hover:border-amber-400"
                  }`}
                >
                  {switchingNetwork === "testnet" ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <RefreshCw className="h-3 w-3" />
                  )}
                  <span>BSC Testnet (97)</span>
                </button>
              </div>
            </div>

            {/* Actions: View on BscScan & Disconnect */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <a
                href={`${explorerBase}/address/${wallet.address}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2 px-3 rounded-lg border border-cyan-400/40 bg-black/40 text-cyan-300 hover:bg-cyan-500/10 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <ExternalLink className="h-3.5 w-3.5" /> View on BscScan
              </a>

              <button
                type="button"
                onClick={() => {
                  disconnectWallet();
                  toast.success("Wallet Disconnected");
                  onOpenChange(false);
                }}
                className="py-2 px-3 rounded-lg border border-red-500/40 bg-red-950/20 text-red-300 hover:bg-red-500/20 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <LogOut className="h-3.5 w-3.5" /> Disconnect
              </button>
            </div>
          </div>
        ) : (
          /* STATE 2: NOT CONNECTED */
          <div className="space-y-4 pt-2">
            {/* Option A: Connect via Browser Extension */}
            {isInstalled ? (
              <button
                type="button"
                onClick={handleConnect}
                disabled={connecting}
                className="btn-neon w-full py-3 px-4 rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2"
              >
                {connecting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Connecting to MetaMask...</span>
                  </>
                ) : (
                  <>
                    <Wallet className="h-4 w-4" />
                    <span>Connect MetaMask Extension</span>
                  </>
                )}
              </button>
            ) : (
              <div className="space-y-2">
                <a
                  href="https://metamask.io/download/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-neon w-full py-3 px-4 rounded-xl font-display font-bold text-sm flex items-center justify-center gap-2"
                >
                  <ExternalLink className="h-4 w-4" />
                  <span>Install MetaMask Extension</span>
                </a>
                <p className="text-[11px] text-center text-muted-foreground">
                  MetaMask is not detected in your browser. Install the official extension to connect.
                </p>
              </div>
            )}

            {/* Option B: Mobile Deep Link */}
            {isMobile && (
              <div className="rounded-xl border border-amber-400/40 bg-amber-950/20 p-3.5 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                  <Smartphone className="h-4 w-4 text-amber-400" /> On Mobile? Open in MetaMask App
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Open this application directly inside the MetaMask mobile browser for seamless wallet transactions.
                </p>
                <a
                  href={getMetaMaskMobileDeepLink()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 px-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Open in MetaMask Mobile</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </a>
              </div>
            )}

            {/* Option C: Create New Wallet Guide Accordion */}
            <div className="rounded-xl border border-cyan-400/30 bg-black/60 overflow-hidden">
              <button
                type="button"
                onClick={() => setShowGuide(!showGuide)}
                className="w-full px-4 py-3 flex items-center justify-between text-left text-xs font-semibold text-cyan-300 hover:bg-cyan-500/10 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <HelpCircle className="h-4 w-4 text-cyan-400" /> Don't have a wallet? How to Create One
                </span>
                <span className="text-cyan-400">{showGuide ? "▲" : "▼"}</span>
              </button>

              {showGuide && (
                <div className="px-4 pb-4 pt-1 space-y-3 text-xs text-muted-foreground border-t border-cyan-400/20">
                  <ol className="list-decimal list-inside space-y-2 leading-relaxed">
                    <li>
                      <strong className="text-foreground">Download MetaMask:</strong> Visit the official site{" "}
                      <a
                        href="https://metamask.io/download/"
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-300 underline"
                      >
                        metamask.io
                      </a>{" "}
                      and install the browser extension or mobile app.
                    </li>
                    <li>
                      <strong className="text-foreground">Select Create a Wallet:</strong> Open the app, choose "Create a new wallet", and set a strong master password.
                    </li>
                    <li>
                      <strong className="text-foreground">Backup Secret Phrase:</strong> Write down your 12-word Secret Recovery Phrase on physical paper and store it in a secure offline location.
                    </li>
                    <li>
                      <strong className="text-foreground">Return Here &amp; Connect:</strong> Once set up, click "Connect MetaMask" to interact with SAKIM AI Assistant.
                    </li>
                  </ol>
                </div>
              )}
            </div>

            {/* SECURITY REMINDER */}
            <div className="rounded-xl border border-emerald-400/30 bg-emerald-950/20 p-3 space-y-1.5 text-xs text-emerald-200">
              <div className="flex items-center gap-1.5 font-bold text-emerald-300">
                <Shield className="h-4 w-4 text-emerald-400" />
                <Lock className="h-3.5 w-3.5 text-emerald-400" />
                <span>Zero-Knowledge Security Policy</span>
              </div>
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                SAKIM AI will <strong>NEVER</strong> ask for your Private Key or Secret Recovery Phrase. Never enter your 12-word seed phrase on any website or chat. All signatures occur exclusively inside your official MetaMask client.
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
