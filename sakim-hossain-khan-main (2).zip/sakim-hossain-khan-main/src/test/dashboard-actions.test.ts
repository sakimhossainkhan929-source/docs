import { describe, expect, it } from "vitest";
import { searchDestination, websiteDestination } from "@/lib/dashboard-actions";

describe("Dashboard browser actions", () => {
  it("opens websites over HTTPS by default", () => {
    expect(websiteDestination("example.com")).toBe("https://example.com/");
  });
  it("rejects executable and local application URLs", () => {
    expect(websiteDestination("javascript:alert(1)")).toBeNull();
    expect(websiteDestination("file:///etc/passwd")).toBeNull();
  });
  it("encodes multilingual web search input", () => {
    expect(searchDestination("हिन्दी AI")).toBe(
      `https://www.google.com/search?q=${encodeURIComponent("हिन्दी AI")}`,
    );
  });
});
