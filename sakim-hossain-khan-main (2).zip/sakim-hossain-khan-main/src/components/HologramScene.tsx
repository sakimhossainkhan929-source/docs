import { useEffect, useRef } from "react";
import * as THREE from "three";
import heroImage from "@/assets/sakim-hero.jpg";

interface HologramSceneProps {
  audioLevel: React.RefObject<number>;
  isLive?: boolean;
  isSpeaking?: boolean;
  isMuted?: boolean;
}

/**
 * Realistic Animated 3D Male AI Avatar (matching the reference image):
 * - Young male cyber assistant with tousled dark hair, realistic facial features, and short goatee
 * - Natural blinking eyelids with sinusoidal easing
 * - Real-time voice-synchronized moving lips and jaw articulation
 * - Interactive 3D head and torso tracking responding to pointer movement and natural breathing
 * - Forward-reaching hand with interactive depth and gesturing
 * - Rotating 3D holographic matrix portal rings behind the avatar
 * - Floating cyber data dust particles and glowing tiered base platform
 */
export function HologramScene({
  audioLevel,
  isLive = false,
  isSpeaking = false,
  isMuted = false,
}: HologramSceneProps) {
  const host = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = host.current;
    if (!container) return;

    let disposed = false;
    let animationFrameId = 0;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030814, 0.05);

    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 50);
    camera.position.set(0, 0.12, 4.4);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2.0));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.domElement.setAttribute("aria-hidden", "true");
    renderer.domElement.style.width = "100%";
    renderer.domElement.style.height = "100%";
    container.appendChild(renderer.domElement);

    // Studio Cyber Lighting
    const ambientLight = new THREE.AmbientLight(0x0c1e3d, 1.8);
    scene.add(ambientLight);

    const cyanRim = new THREE.DirectionalLight(0x00f0ff, 4.0);
    cyanRim.position.set(-2.5, 2.0, -1.0);
    scene.add(cyanRim);

    const goldKey = new THREE.DirectionalLight(0xffd05b, 2.5);
    goldKey.position.set(2.5, 2.5, 2.0);
    scene.add(goldKey);

    const frontFill = new THREE.DirectionalLight(0x88ccff, 2.0);
    frontFill.position.set(0, 0.5, 3.5);
    scene.add(frontFill);

    const baseGlow = new THREE.PointLight(0x00f0ff, 3.0, 6);
    baseGlow.position.set(0, -1.6, 0.8);
    scene.add(baseGlow);

    // Main 3D Rig Group
    const rigGroup = new THREE.Group();
    rigGroup.position.set(0, -0.05, 0);
    scene.add(rigGroup);

    // ==========================================
    // 1. Rotating Holographic Matrix Portal (Behind Avatar)
    // ==========================================
    const portalGroup = new THREE.Group();
    portalGroup.position.set(0, 0.35, -0.6);
    rigGroup.add(portalGroup);

    const portalColors = [0x00f0ff, 0xffd05b, 0x0088ff, 0x00f0ff];
    const portalRings: InstanceType<typeof THREE.Mesh>[] = [];

    for (let i = 0; i < 4; i++) {
      const radius = 1.25 + i * 0.32;
      const ringGeo = new THREE.TorusGeometry(radius, 0.014, 8, 80);
      const ringMat = new THREE.MeshBasicMaterial({
        color: portalColors[i] ?? 0x00f0ff,
        transparent: true,
        opacity: 0.65 - i * 0.1,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      portalGroup.add(ringMesh);
      portalRings.push(ringMesh);

      // Tech tick marks on inner rings
      if (i < 2) {
        const tickGeo = new THREE.BufferGeometry();
        const tickCount = 24 + i * 12;
        const tickPos = new Float32Array(tickCount * 2 * 3);
        for (let t = 0; t < tickCount; t++) {
          const angle = (t / tickCount) * Math.PI * 2;
          const r1 = radius - 0.05;
          const r2 = radius + 0.05;
          tickPos[t * 6] = Math.cos(angle) * r1;
          tickPos[t * 6 + 1] = Math.sin(angle) * r1;
          tickPos[t * 6 + 2] = 0;

          tickPos[t * 6 + 3] = Math.cos(angle) * r2;
          tickPos[t * 6 + 4] = Math.sin(angle) * r2;
          tickPos[t * 6 + 5] = 0;
        }
        tickGeo.setAttribute("position", new THREE.BufferAttribute(tickPos, 3));
        const tickMat = new THREE.LineBasicMaterial({
          color: i === 1 ? 0xffd05b : 0x00f0ff,
          transparent: true,
          opacity: 0.5,
        });
        const ticks = new THREE.LineSegments(tickGeo, tickMat);
        portalGroup.add(ticks);
      }
    }

    // ==========================================
    // 1b. Subtle Falling Numbers Layer (Directly Behind Reference Photo)
    // ==========================================
    const numCanvas = document.createElement("canvas");
    numCanvas.width = 512;
    numCanvas.height = 512;
    const numCtx = numCanvas.getContext("2d");

    const numFontSize = 13;
    const numColumns = 36;
    const numDrops: number[] = [];
    const numSpeeds: number[] = [];
    const numColors: string[] = [];
    const numDigits = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

    for (let i = 0; i < numColumns; i++) {
      numDrops[i] = Math.random() * -30;
      numSpeeds[i] = 0.35 + Math.random() * 0.45;
      numColors[i] = Math.random() < 0.35 ? "#ffd05b" : "#00f0ff";
    }

    const numTexture = new THREE.CanvasTexture(numCanvas);
    numTexture.colorSpace = THREE.SRGBColorSpace;

    const numGeo = new THREE.PlaneGeometry(3.3, 3.3);
    const numMat = new THREE.MeshBasicMaterial({
      map: numTexture,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    const numPlane = new THREE.Mesh(numGeo, numMat);
    numPlane.position.set(0, 0.28, -0.3);
    rigGroup.add(numPlane);

    // ==========================================
    // 2. Realistic Male Avatar Mesh with Dynamic Rig
    // ==========================================
    // Load reference hero image
    const textureLoader = new THREE.TextureLoader();
    let avatarMesh: THREE.Mesh | null = null;
    let shaderUniforms: {
      uTime: { value: number };
      uSpeech: { value: number };
      uBlink: { value: number };
      uPointer: { value: THREE.Vector2 };
    } | null = null;

    textureLoader.load(heroImage, (texture) => {
      if (disposed) return;
      texture.colorSpace = THREE.SRGBColorSpace;

      // Create cropped Canvas texture containing the realistic male character
      const img = texture.image as HTMLImageElement;
      const canvas = document.createElement("canvas");
      canvas.width = 1024;
      canvas.height = 1024;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;

      // Character crop coordinates from 1280x1169 reference image:
      // Avatar center x: 640, top y: 110, bottom y: 950
      const sx = Math.floor(img.width * 0.16);
      const sy = Math.floor(img.height * 0.09);
      const sw = Math.floor(img.width * 0.68);
      const sh = Math.floor(img.height * 0.72);

      // Draw character onto cropped texture with feathered edges
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);

      // Feather perimeter so character sits seamlessly in cyber environment
      const gradientRadial = ctx.createRadialGradient(
        canvas.width * 0.5,
        canvas.height * 0.45,
        canvas.width * 0.35,
        canvas.width * 0.5,
        canvas.height * 0.5,
        canvas.width * 0.52,
      );
      gradientRadial.addColorStop(0, "rgba(0,0,0,0)");
      gradientRadial.addColorStop(0.85, "rgba(3,8,20,0.6)");
      gradientRadial.addColorStop(1, "rgba(3,8,20,1.0)");
      ctx.globalCompositeOperation = "destination-out";
      ctx.fillStyle = gradientRadial;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.globalCompositeOperation = "source-over";

      const avatarTexture = new THREE.CanvasTexture(canvas);
      avatarTexture.colorSpace = THREE.SRGBColorSpace;
      avatarTexture.generateMipmaps = true;

      // Realistic Avatar Shader with Blinking Eyes and Moving Speech Lips
      const vertexShader = `
        varying vec2 vUv;
        varying vec3 vNormal;
        varying vec3 vViewPosition;
        uniform float uTime;
        uniform float uSpeech;
        uniform float uBlink;
        uniform vec2 uPointer;

        void main() {
          vUv = uv;
          vec3 pos = position;

          // Mouth & Jaw coordinates on cropped avatar:
          // Mouth center is approximately at uv: (0.495, 0.435)
          vec2 mouthCenter = vec2(0.495, 0.435);
          float distToMouth = distance(vUv, mouthCenter);
          float mouthMask = smoothstep(0.09, 0.0, distToMouth);

          // Moving lips & jaw articulation with speech audio
          // Deform mouth downwards and forwards when speaking
          if (vUv.y < mouthCenter.y) {
            pos.y -= mouthMask * uSpeech * 0.12;
            pos.z += mouthMask * uSpeech * 0.06;
          } else {
            pos.y += mouthMask * uSpeech * 0.04;
          }

          // Subtle 3D convex curvature for realistic head/torso depth
          float radialDist = distance(vUv, vec2(0.5, 0.5));
          pos.z += cos(radialDist * 3.14159) * 0.22;

          // Forward-reaching hand popping out in 3D perspective
          // Reaching hand is near uv (0.35, 0.22)
          float handDist = distance(vUv, vec2(0.35, 0.22));
          float handMask = smoothstep(0.22, 0.0, handDist);
          pos.z += handMask * (0.35 + sin(uTime * 2.5) * 0.04 + uSpeech * 0.06);
          pos.x += handMask * (sin(uTime * 2.0) * 0.02 + uPointer.x * 0.05);

          vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
          vViewPosition = -mvPosition.xyz;
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * mvPosition;
        }
      `;

      const fragmentShader = `
        varying vec2 vUv;
        varying vec3 vNormal;
        varying vec3 vViewPosition;
        uniform sampler2D uMap;
        uniform float uTime;
        uniform float uSpeech;
        uniform float uBlink;

        void main() {
          vec2 uv = vUv;

          // 1. Voice-Synchronized Lip Movement (Texture UV distortion)
          vec2 mouthCenter = vec2(0.495, 0.435);
          float distMouth = distance(uv, mouthCenter);
          if (distMouth < 0.08) {
            float mouthFactor = exp(-pow(distMouth * 16.0, 2.0));
            // Open mouth vertically proportional to speech level
            uv.y += (uv.y - mouthCenter.y) * mouthFactor * uSpeech * 0.45;
          }

          vec4 color = texture2D(uMap, uv);

          // 2. Natural Blinking Eyes
          // Eye positions: Left eye ~ (0.435, 0.582), Right eye ~ (0.555, 0.578)
          vec2 leftEye = vec2(0.435, 0.582);
          vec2 rightEye = vec2(0.555, 0.578);

          float dLeft = distance(uv, leftEye);
          float dRight = distance(uv, rightEye);

          if ((dLeft < 0.042 || dRight < 0.042) && uBlink > 0.05) {
            // Eyelid closes over the eye
            vec2 eyeCenter = dLeft < dRight ? leftEye : rightEye;
            float eyeY = (uv.y - eyeCenter.y) / 0.042;
            if (abs(eyeY) < uBlink * 1.1) {
              // Blend with realistic eyelid skin tone
              vec3 eyelidSkin = vec3(0.55, 0.38, 0.28) * (0.8 + 0.2 * color.r);
              color.rgb = mix(color.rgb, eyelidSkin, smoothstep(uBlink, uBlink - 0.2, abs(eyeY)));
            }
          }

          // 3. Glowing Cyan LED piping on cyber jacket
          // Check cyan highlights on jacket trim and S emblem
          float isCyanPiping = step(0.5, color.b) * step(0.4, color.g) * (1.0 - step(0.65, color.r));
          if (isCyanPiping > 0.5) {
            float pulse = 1.0 + sin(uTime * 4.0) * 0.35 + uSpeech * 0.5;
            color.rgb += vec3(0.0, 0.6, 1.0) * pulse * 0.4;
          }

          // 4. Subtle holographic rim sheen
          vec3 viewDir = normalize(vViewPosition);
          float fresnel = pow(1.0 - max(dot(viewDir, vNormal), 0.0), 3.0);
          color.rgb += vec3(0.0, 0.8, 1.0) * fresnel * 0.28;

          // Alpha fade at edges
          float alpha = color.a * smoothstep(0.0, 0.08, uv.x) * smoothstep(1.0, 0.92, uv.x) * smoothstep(0.0, 0.05, uv.y);
          gl_FragColor = vec4(color.rgb, alpha);
        }
      `;

      shaderUniforms = {
        uTime: { value: 0 },
        uSpeech: { value: 0 },
        uBlink: { value: 0 },
        uPointer: { value: new THREE.Vector2(0, 0) },
      };

      const avatarGeo = new THREE.PlaneGeometry(3.2, 3.2, 48, 48);
      const avatarMat = new THREE.ShaderMaterial({
        vertexShader,
        fragmentShader,
        uniforms: {
          uMap: { value: avatarTexture },
          uTime: shaderUniforms.uTime,
          uSpeech: shaderUniforms.uSpeech,
          uBlink: shaderUniforms.uBlink,
          uPointer: shaderUniforms.uPointer,
        },
        transparent: true,
        side: THREE.DoubleSide,
      });

      avatarMesh = new THREE.Mesh(avatarGeo, avatarMat);
      avatarMesh.position.set(0, 0.12, 0);
      rigGroup.add(avatarMesh);
    });

    // ==========================================
    // 3. Holographic Base Platform
    // ==========================================
    const baseGroup = new THREE.Group();
    baseGroup.position.set(0, -1.35, 0.2);
    rigGroup.add(baseGroup);

    const baseRings: InstanceType<typeof THREE.Mesh>[] = [];
    for (let i = 0; i < 3; i++) {
      const radius = 1.5 + i * 0.25;
      const bGeo = new THREE.TorusGeometry(radius, 0.015, 8, 64);
      const bMat = new THREE.MeshBasicMaterial({
        color: i === 1 ? 0xffd05b : 0x00f0ff,
        transparent: true,
        opacity: 0.7 - i * 0.18,
      });
      const bMesh = new THREE.Mesh(bGeo, bMat);
      bMesh.rotation.x = Math.PI / 2.3;
      bMesh.position.y = i * 0.08;
      baseGroup.add(bMesh);
      baseRings.push(bMesh);
    }

    // ==========================================
    // 4. Floating Cyber Energy Dust Particles
    // ==========================================
    const particleCount = 100;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleSpeeds: number[] = [];

    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 3.8;
      particlePositions[i * 3 + 1] = (Math.random() - 0.5) * 3.4 + 0.2;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 2.0;
      particleSpeeds.push(0.003 + Math.random() * 0.007);
    }
    particleGeo.setAttribute("position", new THREE.BufferAttribute(particlePositions, 3));

    const particleMat = new THREE.PointsMaterial({
      color: 0x00f0ff,
      size: 0.028,
      transparent: true,
      opacity: 0.65,
    });
    const particles = new THREE.Points(particleGeo, particleMat);
    rigGroup.add(particles);

    // ==========================================
    // 5. Interactive Animation Loop
    // ==========================================
    const pointer = { x: 0, y: 0, targetX: 0, targetY: 0 };
    const handlePointerMove = (e: PointerEvent) => {
      const rect = container.getBoundingClientRect();
      pointer.targetX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.targetY = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
    };
    container.addEventListener("pointermove", handlePointerMove);

    // Blinking parameters
    let blinkTimer = 0;
    let nextBlink = 2.8 + Math.random() * 2.0;
    let isBlinking = false;
    let blinkProgress = 0;

    const clock = new THREE.Clock();

    const resize = () => {
      const width = container.clientWidth;
      const height = container.clientHeight;
      if (!width || !height) return;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);

    const render = () => {
      animationFrameId = requestAnimationFrame(render);
      if (document.hidden) return;

      const delta = Math.min(clock.getDelta(), 0.1);
      const time = clock.getElapsedTime();

      // Smooth pointer tracking
      pointer.x = THREE.MathUtils.damp(pointer.x, pointer.targetX, 4.0, delta);
      pointer.y = THREE.MathUtils.damp(pointer.y, pointer.targetY, 4.0, delta);

      // Natural Human Breathing & Micro-sway
      const breathing = Math.sin(time * 1.8) * 0.02;

      // Realistic Human Head & Torso Tilt with Pointer
      rigGroup.rotation.y = THREE.MathUtils.damp(rigGroup.rotation.y, pointer.x * 0.18, 4.0, delta);
      rigGroup.rotation.x = THREE.MathUtils.damp(
        rigGroup.rotation.x,
        -pointer.y * 0.12,
        4.0,
        delta,
      );
      rigGroup.position.y = -0.05 + breathing;

      // Natural Blinking
      blinkTimer += delta;
      if (blinkTimer > nextBlink && !isBlinking) {
        isBlinking = true;
        blinkProgress = 0;
      }

      let currentBlink = 0;
      if (isBlinking) {
        blinkProgress += delta * 12.0; // Quick natural blink (~120ms)
        if (blinkProgress >= Math.PI) {
          isBlinking = false;
          blinkTimer = 0;
          nextBlink = 2.4 + Math.random() * 3.0;
          currentBlink = 0;
        } else {
          currentBlink = Math.sin(blinkProgress);
        }
      }

      // Voice-Synchronized Lip & Speech calculation
      const liveSpeechLevel = audioLevel.current ?? 0;
      const activeSpeaking = isSpeaking || liveSpeechLevel > 0.05;
      const speechAmplitude = activeSpeaking
        ? Math.max(liveSpeechLevel * 1.4, Math.sin(time * 15.0) * 0.35 + 0.45)
        : 0;

      // Update Shader Uniforms
      if (shaderUniforms) {
        shaderUniforms.uTime.value = time;
        shaderUniforms.uSpeech.value = THREE.MathUtils.damp(
          shaderUniforms.uSpeech.value,
          speechAmplitude,
          16.0,
          delta,
        );
        shaderUniforms.uBlink.value = currentBlink;
        shaderUniforms.uPointer.value.set(pointer.x, pointer.y);
      }

      // Rotate Holographic Matrix Portal Rings
      portalRings.forEach((ring, i) => {
        ring.rotation.z += (i % 2 === 0 ? 0.006 : -0.009) * (1 + (activeSpeaking ? 1.4 : 0));
      });

      // Update subtle falling numbers procedural texture behind reference photo
      if (numCtx) {
        numCtx.fillStyle = "rgba(2, 6, 18, 0.22)";
        numCtx.fillRect(0, 0, 512, 512);

        numCtx.font = '700 13px "Courier New", monospace';

        const colWidth = 512 / numColumns;
        for (let i = 0; i < numColumns; i++) {
          const currentDrop = numDrops[i] ?? 0;
          const x = i * colWidth + 2;
          const y = currentDrop * numFontSize;
          const baseColor = numColors[i] || "#00f0ff";
          const isGold = baseColor === "#ffd05b";

          // Dynamically mutating digits - strictly NO static digits
          const char = numDigits[Math.floor(Math.random() * numDigits.length)] ?? "0";

          // Head glowing character with radiant cyan or gold bloom
          numCtx.fillStyle = isGold ? "#fff9db" : "#e0faff";
          numCtx.shadowBlur = 10;
          numCtx.shadowColor = baseColor;
          numCtx.fillText(char, x, y);

          // Trail of 3 falling digits behind head
          for (let t = 1; t <= 3; t++) {
            const ty = y - t * numFontSize;
            if (ty > 0) {
              const trailChar = numDigits[Math.floor(Math.random() * numDigits.length)] ?? "1";
              numCtx.fillStyle = baseColor;
              numCtx.shadowBlur = t === 1 ? 5 : 2;
              numCtx.fillText(trailChar, x, ty);
            }
          }

          numCtx.shadowBlur = 0;

          if (y > 512 && Math.random() > 0.96) {
            numDrops[i] = -Math.random() * 20;
            numSpeeds[i] = 0.35 + Math.random() * 0.45;
            numColors[i] = Math.random() < 0.35 ? "#ffd05b" : "#00f0ff";
          }

          numDrops[i] = currentDrop + (numSpeeds[i] ?? 0.4);
        }

        // Feathered circular mask so falling numbers sit subtly behind the avatar
        const radGrad = numCtx.createRadialGradient(256, 256, 110, 256, 256, 256);
        radGrad.addColorStop(0, "rgba(0,0,0,0)");
        radGrad.addColorStop(0.72, "rgba(2,6,18,0.2)");
        radGrad.addColorStop(1, "rgba(2,6,18,0.9)");
        numCtx.globalCompositeOperation = "destination-out";
        numCtx.fillStyle = radGrad;
        numCtx.fillRect(0, 0, 512, 512);
        numCtx.globalCompositeOperation = "source-over";

        numTexture.needsUpdate = true;
      }

      // Rotate Base Platform Rings
      baseRings.forEach((ring, i) => {
        ring.rotation.z += i % 2 === 0 ? 0.008 : -0.006;
      });

      // Animate floating cyber data dust
      const posAttr = particleGeo.attributes.position;
      if (posAttr) {
        const arr = posAttr.array as Float32Array;
        for (let i = 0; i < particleCount; i++) {
          arr[i * 3 + 1] += particleSpeeds[i] ?? 0.005;
          if (arr[i * 3 + 1] > 2.2) {
            arr[i * 3 + 1] = -1.5;
            arr[i * 3] = (Math.random() - 0.5) * 3.8;
          }
        }
        posAttr.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      disposed = true;
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      container.removeEventListener("pointermove", handlePointerMove);
      numTexture.dispose();
      numGeo.dispose();
      numMat.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [audioLevel, isLive, isSpeaking, isMuted]);

  return (
    <div
      ref={host}
      className="hologram-scene relative h-full w-full overflow-hidden"
      role="img"
      aria-label="Ziggy, a realistic animated 3D human AI assistant matching reference"
    />
  );
}
