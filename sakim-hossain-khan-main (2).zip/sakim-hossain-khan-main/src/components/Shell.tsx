import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { WalletButton } from "@/components/WalletButton";

const DIGITS = Array.from({ length: 18 }, (_, i) => ({
  left: (i * 37) % 100,
  delay: (i * 1.3) % 8,
  dur: 7 + (i % 5) * 2,
  text: Array.from({ length: 8 }, (_, k) => ((i + k) % 3 ? "1" : "0")).join("\n"),
}));

export function DigitRain() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {DIGITS.map((d, i) => (
        <pre
          key={i}
          className="animate-fall absolute top-0 font-display text-xs leading-4 text-primary/40"
          style={{
            left: `${d.left}%`,
            animationDelay: `${d.delay}s`,
            animationDuration: `${d.dur}s`,
          }}
        >
          {d.text}
        </pre>
      ))}
    </div>
  );
}

export function Shell({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div className="min-h-screen">
      <DigitRain />
      <header className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-5">
        <Link
          to="/"
          className="font-display text-sm font-extrabold tracking-widest text-neon sm:text-base"
        >
          SAKIM
        </Link>
        <nav className="flex items-center gap-3 text-xs text-muted-foreground sm:gap-5 sm:text-sm">
          <Link to="/create" activeProps={{ className: "text-primary" }}>
            Create
          </Link>
          <Link to="/tokens" activeProps={{ className: "text-primary" }}>
            My Tokens
          </Link>
          <Link to="/launchpad" activeProps={{ className: "text-primary" }}>
            Launchpad
          </Link>
          <WalletButton variant="chip" />
        </nav>
      </header>
      <main className="mx-auto max-w-5xl px-4 pb-16">
        <h1 className="mb-6 font-display text-2xl font-extrabold text-neon sm:text-3xl">{title}</h1>
        {children}
      </main>
    </div>
  );
}

export function DemoBadge({ label = "Demo Preview" }: { label?: string }) {
  return (
    <span className="rounded-full border border-gold/60 px-3 py-1 text-xs font-semibold uppercase tracking-wider text-gold">
      {label}
    </span>
  );
}
