import { useState } from "react";
import { LogOut, Wallet } from "lucide-react";
import {
  chainName,
  disconnectWallet,
  shortAddress,
  useWallet,
} from "@/lib/wallet";
import { WalletModal } from "@/components/WalletModal";

export function WalletButton({ variant = "full" }: { variant?: "full" | "chip" | "hud-pill" }) {
  const wallet = useWallet();
  const [modalOpen, setModalOpen] = useState(false);

  const isConnected = Boolean(wallet.address);

  if (variant === "hud-pill") {
    return (
      <>
        <button
          type="button"
          onClick={() => setModalOpen(true)}
          className="cyber-wallet-badge group flex items-center gap-3 px-4 py-2 text-left transition-all hover:scale-[1.02]"
          title={
            isConnected
              ? `Connected: ${wallet.address} (Click to manage wallet)`
              : "Connect MetaMask Wallet"
          }
        >
          {/* MetaMask Fox SVG */}
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#e2761b]/15 p-1 border border-[#e2761b]/40 shadow-[0_0_12px_rgba(226,118,27,0.3)]">
            <svg viewBox="0 0 32 32" className="h-7 w-7" aria-hidden="true">
              <path
                fill="#e2761b"
                d="m28.6 4.7-10.2 7.6 1.9-4.5zM3.4 4.7l10.1 7.6-1.8-4.5zM24.7 21.8l-2.7 4.1 5.9 1.6 1.7-5.6zM7.3 21.8l-4.9.1 1.7 5.6 5.9-1.6z"
              />
              <path
                fill="#e4761b"
                d="m8.7 13.9-1.6 2.4 5.7.3-.2-6.2zM23.3 13.9l-3.9-3.5-.2 6.2 5.7-.3zM10 25.9l3.4-1.7-3-2.3zM22 25.9l-.4-4-3 2.3z"
              />
              <path
                fill="#d7c1b3"
                d="m18.6 24.2 3-2.3-.4-4-5.2-.4.4 3.7zM10.4 21.9l3 2.3 2.2-3-.4-3.7-5.2.4z"
              />
              <path
                fill="#233447"
                d="m10.8 17.9 4.8-.4-.4-3.7-4.4.2zM21.2 17.9l.4-3.9-4.4-.2-.4 3.7z"
              />
              <path
                fill="#cd6116"
                d="m13.4 24.2-3.4 1.7 1.4 1.9 4.2-1.1zM18.6 24.2-2.2 2.5 4.2 1.1 1.4-1.9z"
              />
              <path
                fill="#e4751f"
                d="m18.6 24.2-2.6 2.5 2.6 1.1 3.4-1.9zM13.4 24.2-3.4 1.7 2.6-1.1-2.6-2.5z"
              />
            </svg>
          </div>

          <div className="flex flex-col">
            <span className="font-display text-xs font-bold tracking-wide text-white drop-shadow-[0_0_6px_rgba(255,255,255,0.4)]">
              MetaMask
            </span>
            <span className="flex items-center gap-1.5 text-[10px] font-semibold text-cyan-400">
              {isConnected ? (
                <>
                  <span className="inline-block h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]" />
                  {shortAddress(wallet.address!)}
                </>
              ) : (
                <>
                  <span className="inline-block h-2 w-2 rounded-full bg-amber-400 shadow-[0_0_8px_#fbbf24]" />
                  Connect Wallet
                </>
              )}
            </span>
          </div>
        </button>
        <WalletModal open={modalOpen} onOpenChange={setModalOpen} />
      </>
    );
  }

  if (wallet.address && variant === "chip") {
    const chain = chainName(wallet.chainId);
    return (
      <>
        <span
          onClick={() => setModalOpen(true)}
          className="glass flex items-center gap-2 rounded-full px-3 py-1.5 text-xs cursor-pointer hover:border-cyan-400"
        >
          <Wallet className="h-3.5 w-3.5 text-primary" aria-hidden />
          <span className="font-semibold text-primary">{shortAddress(wallet.address)}</span>
          {chain ? <span className="hidden text-muted-foreground sm:inline">{chain}</span> : null}
          <button
            aria-label="Disconnect wallet"
            onClick={(e) => {
              e.stopPropagation();
              disconnectWallet();
            }}
            className="text-muted-foreground hover:text-destructive"
          >
            <LogOut className="h-3.5 w-3.5" aria-hidden />
          </button>
        </span>
        <WalletModal open={modalOpen} onOpenChange={setModalOpen} />
      </>
    );
  }

  if (variant === "chip") {
    return (
      <>
        <button
          type="button"
          onClick={() => setModalOpen(true)}
          className="glass flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-semibold hover:text-primary"
        >
          <Wallet className="h-3.5 w-3.5 text-primary" aria-hidden />
          Connect Wallet
        </button>
        <WalletModal open={modalOpen} onOpenChange={setModalOpen} />
      </>
    );
  }

  if (wallet.address) {
    const chain = chainName(wallet.chainId);
    return (
      <>
        <div className="glass col-span-1 space-y-1.5 px-6 py-4 text-left sm:col-span-2">
          <div className="flex items-center justify-between gap-3">
            <p
              onClick={() => setModalOpen(true)}
              className="flex items-center gap-2 font-semibold cursor-pointer hover:underline"
            >
              <Wallet className="h-4 w-4 text-primary" aria-hidden />
              <span className="font-display text-primary">{shortAddress(wallet.address)}</span>
            </p>
            <button
              onClick={disconnectWallet}
              className="text-xs text-muted-foreground hover:text-destructive"
            >
              Disconnect
            </button>
          </div>
          <p className="text-xs text-muted-foreground">
            {wallet.balance ?? "…"} · {chain || "Wallet connected"}
          </p>
        </div>
        <WalletModal open={modalOpen} onOpenChange={setModalOpen} />
      </>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setModalOpen(true)}
        className="glass col-span-1 flex items-center justify-center gap-2 px-6 py-4 font-semibold hover:text-primary sm:col-span-2"
      >
        <Wallet className="h-4 w-4 text-primary" aria-hidden />
        Connect Wallet
        <span className="text-xs text-gold">· MetaMask</span>
      </button>
      <WalletModal open={modalOpen} onOpenChange={setModalOpen} />
    </>
  );
}
