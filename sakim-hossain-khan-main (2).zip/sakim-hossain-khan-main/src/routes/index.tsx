import { createFileRoute } from "@tanstack/react-router";
import { AIDashboard } from "@/components/AIDashboard";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sakim AI Assistant — Ziggy Command Center" },
      {
        name: "description",
        content:
          "Meet Ziggy, your multilingual voice assistant. Search the web, open your workspace and manage SAKIM token previews.",
      },
      { property: "og:title", content: "Sakim AI Assistant — Ziggy Command Center" },
      {
        property: "og:description",
        content:
          "Your blue-and-gold AI command center with Ziggy voice, web search and SAKIM crypto tools.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <AIDashboard />;
}
