import "./lib/error-capture";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";
import { handleLiveRequest } from "./lib/live-relay.server";

type ServerEntry = {
  fetch: (request: Request, env: unknown, ctx: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isH3SwallowedErrorBody(body)) return response;

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isH3SwallowedErrorBody(body: string): boolean {
  try {
    const payload = JSON.parse(body) as { unhandled?: unknown; message?: unknown };
    return payload.unhandled === true && payload.message === "HTTPError";
  } catch {
    return false;
  }
}

export default {
  async fetch(request: Request, env: unknown, ctx: unknown) {
    try {
      const url = new URL(request.url);
      if (url.pathname === "/api/live") {
        return handleLiveRequest(request);
      }
      if (url.pathname === "/api/token/pricing" && request.method === "GET") {
        const {
          MIN_SERVICE_PAYMENT_USD,
          ESTIMATED_GAS_FEE_USD,
          DEFAULT_BNB_PRICE_USD,
          getAdminCommissionConfig,
        } = await import("./lib/token-payment.server");
        const adminConfig = getAdminCommissionConfig();
        return new Response(
          JSON.stringify({
            minServicePaymentUsd: MIN_SERVICE_PAYMENT_USD,
            estimatedGasFeeUsd: ESTIMATED_GAS_FEE_USD,
            bnbPriceUsd: DEFAULT_BNB_PRICE_USD,
            treasuryAddress: adminConfig.adminCommissionAddress,
            adminCommissionAddress: adminConfig.adminCommissionAddress,
          }),
          {
            status: 200,
            headers: { "content-type": "application/json; charset=utf-8" },
          },
        );
      }
      if (url.pathname === "/api/admin/commission" && request.method === "GET") {
        const { getAdminCommissionConfig } = await import("./lib/token-payment.server");
        const config = getAdminCommissionConfig();
        return new Response(JSON.stringify(config), {
          status: 200,
          headers: { "content-type": "application/json; charset=utf-8" },
        });
      }
      if (url.pathname === "/api/admin/commission" && request.method === "POST") {
        const { updateAdminCommissionAddress } = await import("./lib/token-payment.server");
        const body = (await request.json()) as { address?: string };
        const result = updateAdminCommissionAddress(body.address || "");
        return new Response(JSON.stringify(result), {
          status: result.ok ? 200 : 400,
          headers: { "content-type": "application/json; charset=utf-8" },
        });
      }
      if (url.pathname === "/api/token/deploy" && request.method === "POST") {
        const { processTokenDeployment } = await import("./lib/token-payment.server");
        const body = (await request.json()) as Parameters<typeof processTokenDeployment>[0];
        const result = await processTokenDeployment(body);
        return new Response(JSON.stringify(result), {
          status: result.ok ? 200 : 400,
          headers: { "content-type": "application/json; charset=utf-8" },
        });
      }
      if (url.pathname === "/api/chat" && request.method === "POST") {
        const { processGeminiChat } = await import("./lib/gemini.server");
        const body = (await request.json()) as Parameters<typeof processGeminiChat>[0];
        const result = await processGeminiChat(body);
        return new Response(JSON.stringify(result), {
          status: 200,
          headers: { "content-type": "application/json; charset=utf-8" },
        });
      }
      const handler = await getServerEntry();
      const response = await handler.fetch(request, env, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};
