import { describe, expect, it } from "vitest";
import { MIN_SERVICE_PAYMENT_USD, processTokenDeployment } from "../lib/token-payment.server";

describe("Token Payment & Deployment System", () => {
  it("enforces minimum service payment of $0.50 USD", async () => {
    expect(MIN_SERVICE_PAYMENT_USD).toBe(0.5);

    const underpaid = await processTokenDeployment({
      token: { name: "Low Fee Token", symbol: "LOW", supply: 1000 },
      payment: { amountUsd: 0.25 },
    });

    expect(underpaid.ok).toBe(false);
    expect(underpaid.error).toContain("Minimum service payment amount is $0.50 USD");
  });

  it("accepts payment of exactly $0.50 USD", async () => {
    const minPaid = await processTokenDeployment({
      token: { name: "Sakim Starter", symbol: "START", supply: 50000 },
      payment: { amountUsd: 0.5 },
    });

    expect(minPaid.ok).toBe(true);
    expect(minPaid.verified).toBe(true);
    expect(minPaid.token).toBeDefined();
    expect(minPaid.token?.serviceFeePaidUsd).toBe(0.5);
    expect(minPaid.token?.gasFeePaidUsd).toBe(0.28);
    expect(minPaid.token?.totalPaidUsd).toBe(0.78);
    expect(minPaid.token?.contractAddress).toMatch(/^0x[a-fA-F0-9]{40}$/);
    expect(minPaid.token?.network).toBe("BNB Smart Chain (BEP-20)");
  });

  it("supports large payments with no fixed maximum ($1,000+)", async () => {
    const highPaid = await processTokenDeployment({
      token: { name: "Enterprise AI", symbol: "ENTAI", supply: 10000000 },
      payment: { amountUsd: 2500.0 },
    });

    expect(highPaid.ok).toBe(true);
    expect(highPaid.verified).toBe(true);
    expect(highPaid.token?.serviceFeePaidUsd).toBe(2500.0);
    expect(highPaid.token?.totalPaidUsd).toBe(2500.28);
    expect(highPaid.token?.contractAddress).toMatch(/^0x[a-fA-F0-9]{40}$/);
  });

  it("validates token input parameters strictly", async () => {
    const invalidSymbol = await processTokenDeployment({
      token: { name: "Valid Name", symbol: "", supply: 1000 },
      payment: { amountUsd: 1.0 },
    });
    expect(invalidSymbol.ok).toBe(false);
    expect(invalidSymbol.error).toContain("Symbol must be");
  });
});
