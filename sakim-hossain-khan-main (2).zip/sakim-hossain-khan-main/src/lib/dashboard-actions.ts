/** Only explicit public HTTP destinations may be opened by dashboard tools. */
export function websiteDestination(input: string): string | null {
  const value = input.trim();
  if (!value || /\s/.test(value)) return null;
  try {
    const url = new URL(/^[a-z][a-z\d+.-]*:/i.test(value) ? value : `https://${value}`);
    if (
      !["https:", "http:"].includes(url.protocol) ||
      url.username ||
      url.password ||
      !url.hostname.includes(".")
    )
      return null;
    return url.href;
  } catch {
    return null;
  }
}

export function searchDestination(query: string): string | null {
  const term = query.trim();
  return term ? `https://www.google.com/search?q=${encodeURIComponent(term)}` : null;
}
