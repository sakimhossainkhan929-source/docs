import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, PhoneOff, Volume2 } from "lucide-react";
import { useLiveVoice } from "@/hooks/use-live-voice";

type Mood = "idle" | "listening" | "thinking" | "speaking" | "happy";

const LABELS: Record<Mood, string> = {
  idle: "Say “Ziggy” or tap me to talk",
  listening: "Listening — speak any language",
  thinking: "Thinking…",
  speaking: "Ziggy is speaking",
  happy: "Ziggy is happy to help",
};

interface SpeechRecognitionEvent {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      [index: number]: {
        transcript: string;
      };
    };
  };
}

interface SpeechRecognitionErrorEvent {
  error: string;
}

type SR = {
  start(): void;
  stop(): void;
  abort(): void;
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: SpeechRecognitionEvent) => void) | null;
  onend: (() => void) | null;
  onerror: ((e: SpeechRecognitionErrorEvent) => void) | null;
};
const WAKE = /(ziggy|ziggi|ziggie|जिग्गी|ज़िग्गी|जिगी|জিগি|জিগ্গি|জিগী)/i;

/** Average loudness 0..1 of an analyser. */
function level(a: AnalyserNode, buf: Uint8Array) {
  a.getByteFrequencyData(buf as Uint8Array<ArrayBuffer>);
  let s = 0;
  for (let i = 2; i < 40; i++) s += buf[i] ?? 0;
  return Math.min(1, s / 38 / 140);
}

export function ZiggyAvatar() {
  const voice = useLiveVoice({});
  const idle = voice.status === "idle" || voice.status === "closed";
  const live = voice.status === "connected";
  const [mood, setMood] = useState<Mood>("idle");
  const [wakeOn, setWakeOn] = useState(false);
  const [wakeSupported, setWakeSupported] = useState(false);
  const mouth = useRef<SVGPathElement>(null);
  const head = useRef<SVGGElement>(null);
  const handL = useRef<SVGGElement>(null);
  const handR = useRef<SVGGElement>(null);
  const moodRef = useRef<Mood>("idle");
  const startRef = useRef(voice.start);
  startRef.current = voice.start;

  // Lip-sync + expression loop: runs only while a call is live.
  useEffect(() => {
    if (!live) {
      setMood("idle");
      moodRef.current = "idle";
      return;
    }
    const ctx = new AudioContext();
    const out = ctx.createAnalyser();
    const mic = ctx.createAnalyser();
    out.fftSize = mic.fftSize = 256;
    const bo = new Uint8Array(out.frequencyBinCount);
    const bm = new Uint8Array(mic.frequencyBinCount);
    let outSrc: MediaStream | null = null;
    let micStream: MediaStream | null = null;
    let raf = 0;
    let open = 0;
    let lastUser = 0;
    let lastAi = 0;
    let frame = 0;
    navigator.mediaDevices
      ?.getUserMedia({ audio: { echoCancellation: true } })
      .then((s) => {
        micStream = s;
        ctx.createMediaStreamSource(s).connect(mic);
      })
      .catch(() => {});

    const tick = (t: number) => {
      raf = requestAnimationFrame(tick);
      if (frame++ % 2) return; // ~30fps is plenty and saves battery
      const src = voice.audioRef.current?.srcObject as MediaStream | null;
      if (src && src !== outSrc && src.getAudioTracks().length) {
        outSrc = src;
        try {
          ctx.createMediaStreamSource(src).connect(out);
        } catch {
          /* ignore */
        }
      }
      const ai = outSrc ? level(out, bo) : 0;
      const user = micStream && !voice.muted ? level(mic, bm) : 0;
      if (ai > 0.06) lastAi = t;
      if (user > 0.12 && ai < 0.06) lastUser = t;
      let m: Mood = "listening";
      if (t - lastAi < 250) m = "speaking";
      else if (lastAi && t - lastAi < 1800 && lastAi > lastUser) m = "happy";
      else if (lastUser && t - lastUser > 500 && t - lastUser < 6000 && lastUser > lastAi)
        m = "thinking";
      if (m !== moodRef.current) {
        moodRef.current = m;
        setMood(m);
      }
      open += ((m === "speaking" ? ai : 0) - open) * 0.5;
      const o = 4 + open * 26;
      mouth.current?.setAttribute(
        "d",
        `M80 132 Q100 ${132 + o} 120 132 Q100 ${136 + o * 0.4} 80 132Z`,
      );
      const sway = m === "speaking" ? Math.sin(t / 220) * open * 6 : 0;
      head.current?.setAttribute("transform", `rotate(${sway} 100 100)`);
      const wave = m === "speaking" ? Math.sin(t / 160) * 18 * open : 0;
      handL.current?.setAttribute("transform", `rotate(${-wave} 28 120)`);
      handR.current?.setAttribute("transform", `rotate(${wave} 172 120)`);
    };
    raf = requestAnimationFrame(tick);
    const headNode = head.current;
    const handLNode = handL.current;
    const handRNode = handR.current;
    const mouthNode = mouth.current;

    return () => {
      cancelAnimationFrame(raf);
      micStream?.getTracks().forEach((tr) => tr.stop());
      void ctx.close();
      headNode?.removeAttribute("transform");
      handLNode?.removeAttribute("transform");
      handRNode?.removeAttribute("transform");
      mouthNode?.removeAttribute("d");
    };
  }, [live, voice.muted, voice.audioRef]);

  // Wake word "Ziggy" via the browser's speech recognition, only while no call is running.
  useEffect(() => {
    const win = window as unknown as {
      SpeechRecognition?: new () => SR;
      webkitSpeechRecognition?: new () => SR;
    };
    const Ctor = win.SpeechRecognition || win.webkitSpeechRecognition;
    setWakeSupported(!!Ctor);
    if (!Ctor || !wakeOn || !idle) return;
    let stopped = false;
    const rec: SR = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = "en-IN";
    rec.onresult = (e: SpeechRecognitionEvent) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const item = e.results[i]?.[0];
        if (item && WAKE.test(item.transcript)) {
          stopped = true;
          rec.abort();
          startRef.current();
          return;
        }
      }
    };
    rec.onerror = (e: SpeechRecognitionErrorEvent) => {
      if (e.error === "not-allowed") {
        stopped = true;
        setWakeOn(false);
      }
    };
    rec.onend = () => {
      if (!stopped)
        try {
          rec.start();
        } catch {
          /* ignore */
        }
    };
    try {
      rec.start();
    } catch {
      /* ignore */
    }
    return () => {
      stopped = true;
      rec.abort();
    };
  }, [wakeOn, idle]);

  const tap = () => {
    if (idle) {
      setWakeOn(true);
      voice.start();
    }
  };

  const happy = mood === "happy";
  const thinking = mood === "thinking";

  return (
    <div className="absolute inset-0 z-10">
      <button
        onClick={tap}
        disabled={!idle}
        aria-label={idle ? "Talk to Ziggy" : "Ziggy is in a call"}
        className="relative z-10 h-full w-full p-6"
      >
        <svg
          viewBox="0 0 200 200"
          className={`h-full w-full ${idle ? "animate-floaty" : ""}`}
          role="img"
          aria-label={`Ziggy the smiling Earth — ${LABELS[mood]}`}
        >
          <defs>
            <radialGradient id="zg-ocean" cx="40%" cy="35%" r="70%">
              <stop offset="0%" stopColor="var(--color-primary)" />
              <stop offset="100%" stopColor="var(--color-accent)" />
            </radialGradient>
            <clipPath id="zg-clip">
              <circle cx="100" cy="100" r="72" />
            </clipPath>
          </defs>
          <g ref={handL}>
            <ellipse cx="22" cy="128" rx="10" ry="14" fill="var(--color-gold)" />
            <path
              d="M28 120 L40 110"
              stroke="var(--color-gold)"
              strokeWidth="8"
              strokeLinecap="round"
            />
          </g>
          <g ref={handR}>
            <ellipse cx="178" cy="128" rx="10" ry="14" fill="var(--color-gold)" />
            <path
              d="M172 120 L160 110"
              stroke="var(--color-gold)"
              strokeWidth="8"
              strokeLinecap="round"
            />
          </g>
          <g ref={head} className={thinking ? "zg-tilt" : ""}>
            <circle cx="100" cy="100" r="72" fill="url(#zg-ocean)" />
            <g clipPath="url(#zg-clip)" opacity="0.75">
              <g className="zg-rotate" fill="var(--color-gold)">
                {[0, 200].map((x) => (
                  <g key={x} transform={`translate(${x} 0)`}>
                    <path d="M40 55 q20 -12 40 0 q6 18 -10 28 q-22 4 -30 -10z" />
                    <path d="M110 70 q25 -6 35 10 q-4 22 -24 20 q-14 -10 -11 -30z" />
                    <path d="M60 130 q18 -6 30 8 q-2 20 -20 24 q-14 -12 -10 -32z" />
                    <path d="M150 140 q20 -4 26 10 q-10 14 -24 6z" />
                  </g>
                ))}
              </g>
            </g>
            <circle
              cx="100"
              cy="100"
              r="72"
              fill="none"
              stroke="var(--color-primary)"
              strokeOpacity="0.6"
              strokeWidth="2"
            />
            {/* eyes */}
            <g className={mood === "idle" || mood === "listening" ? "zg-blink" : ""}>
              {[76, 124].map((x) => (
                <g key={x}>
                  {happy ? (
                    <path
                      d={`M${x - 9} 98 Q${x} 86 ${x + 9} 98`}
                      stroke="var(--color-background)"
                      strokeWidth="5"
                      fill="none"
                      strokeLinecap="round"
                    />
                  ) : (
                    <>
                      <ellipse
                        cx={x}
                        cy="94"
                        rx="9"
                        ry={mood === "listening" ? 12 : 10}
                        fill="var(--color-foreground)"
                      />
                      <circle
                        cx={x + (thinking ? 3 : 0)}
                        cy={thinking ? 89 : 95}
                        r="5"
                        fill="var(--color-background)"
                      />
                    </>
                  )}
                </g>
              ))}
            </g>
            {/* cheeks */}
            <circle
              cx="62"
              cy="116"
              r="7"
              fill="var(--color-destructive)"
              opacity={happy ? 0.45 : 0.2}
            />
            <circle
              cx="138"
              cy="116"
              r="7"
              fill="var(--color-destructive)"
              opacity={happy ? 0.45 : 0.2}
            />
            {/* mouth */}
            <path
              ref={mouth}
              d={
                thinking
                  ? "M88 136 Q100 132 112 136 Q100 138 88 136Z"
                  : "M78 128 Q100 150 122 128 Q100 138 78 128Z"
              }
              fill="var(--color-background)"
            />
          </g>
        </svg>
      </button>
      <div className="absolute -bottom-20 left-1/2 w-72 -translate-x-1/2 text-center">
        <p role="status" className="font-semibold text-primary">
          {voice.status === "connecting"
            ? "Connecting…"
            : voice.muted && live
              ? "Microphone muted"
              : LABELS[mood]}
        </p>
        <p className="text-xs text-muted-foreground">
          हिन्दी, English & more{idle && !wakeSupported ? " · tap to talk" : ""}
        </p>
        {voice.error && (
          <p role="alert" className="text-xs text-destructive">
            {voice.error}
          </p>
        )}
        {!idle && (
          <div className="mt-2 flex justify-center gap-2">
            <button
              disabled={!live}
              onClick={() => voice.setMuted(!voice.muted)}
              className="glass flex items-center gap-1 px-3 py-1 text-xs font-semibold hover:text-primary disabled:opacity-40"
            >
              {voice.muted ? <Mic className="h-3 w-3" /> : <MicOff className="h-3 w-3" />}
              {voice.muted ? "Unmute" : "Mute"}
            </button>
            <button
              disabled={voice.status === "stopping"}
              onClick={voice.stop}
              className="glass flex items-center gap-1 px-3 py-1 text-xs font-semibold text-destructive disabled:opacity-40"
            >
              <PhoneOff className="h-3 w-3" /> End
            </button>
            {voice.playbackBlocked && (
              <button
                onClick={voice.resumePlayback}
                className="btn-neon flex items-center gap-1 rounded-lg px-3 py-1 text-xs font-bold"
              >
                <Volume2 className="h-3 w-3" /> Play
              </button>
            )}
          </div>
        )}
      </div>
      <audio ref={voice.audioRef} className="sr-only" />
    </div>
  );
}
