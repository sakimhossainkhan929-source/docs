import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Check,
  Coins,
  Copy,
  ExternalLink,
  Layers,
  Loader2,
  Lock,
  RefreshCw,
  Save,
  ShieldCheck,
  Wallet,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { shortAddress } from "@/lib/wallet";

interface PaymentRecord {
  id: string;
  txHash: string;
  senderAddress: string;
  recipientAddress: string;
  amountUsd: number;
  amountBnb: number;
  gasFeeUsd: number;
  totalPaidUsd: number;
  network: string;
  networkId: number;
  tokenName: string;
  tokenSymbol: string;
  contractAddress: string;
  timestamp: string;
  status: "verified" | "pending" | "failed";
  explorerUrl: string;
}

interface AdminCommissionData {
  adminCommissionAddress: string;
  totalCommissionEarnedUsd: number;
  totalCommissionEarnedBnb: number;
  totalPaymentsCount: number;
  recentPayments: PaymentRecord[];
}

interface AdminCommissionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AdminCommissionModal({ open, onOpenChange }: AdminCommissionModalProps) {
  const [data, setData] = useState<AdminCommissionData | null>(null);
  const [loading, setLoading] = useState(false);
  const [addressInput, setAddressInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  const fetchCommissionData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/commission");
      if (res.ok) {
        const json: AdminCommissionData = await res.json();
        setData(json);
        setAddressInput(json.adminCommissionAddress);
      }
    } catch (err) {
      console.error("Failed to fetch admin commission data:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      void fetchCommissionData();
    }
  }, [open]);

  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    const clean = addressInput.trim();
    if (!/^0x[a-fA-F0-9]{40}$/.test(clean)) {
      toast.error("Invalid BNB Smart Chain Address", {
        description: "Address must be a 42-character hexadecimal EVM address starting with 0x.",
      });
      return;
    }

    setSaving(true);
    try {
      const res = await fetch("/api/admin/commission", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ address: clean }),
      });
      const result = await res.json();
      if (res.ok && result.ok) {
        toast.success("Admin Commission Wallet Updated", {
          description: "New platform service fees will now be transferred to this wallet.",
        });
        await fetchCommissionData();
      } else {
        toast.error("Failed to update wallet", { description: result.error });
      }
    } catch {
      toast.error("Network error updating address");
    } finally {
      setSaving(false);
    }
  };

  const copyAddress = () => {
    if (!data?.adminCommissionAddress) return;
    navigator.clipboard.writeText(data.adminCommissionAddress);
    setCopied(true);
    toast.success("Admin address copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sakim-hud-dialog sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-500/20 text-amber-300 border border-amber-400/50 shadow-[0_0_12px_rgba(255,208,91,0.4)]">
                <Coins className="h-5 w-5" />
              </div>
              <div>
                <DialogTitle className="font-display text-amber-300 drop-shadow-[0_0_8px_rgba(255,208,91,0.6)]">
                  Admin Commission Wallet
                </DialogTitle>
                <DialogDescription className="text-muted-foreground text-xs">
                  Owner Revenue Dashboard &amp; Platform Service Fee Configuration
                </DialogDescription>
              </div>
            </div>

            <button
              type="button"
              onClick={fetchCommissionData}
              disabled={loading}
              className="p-1.5 rounded-lg border border-cyan-400/30 text-cyan-400 hover:bg-cyan-500/10 transition-colors"
              title="Refresh Stats"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </DialogHeader>

        <div className="space-y-5 pt-2">
          {/* STATS OVERVIEW CARDS */}
          <div className="grid grid-cols-3 gap-3">
            <div className="rounded-xl border border-amber-400/30 bg-black/60 p-3.5 space-y-1">
              <span className="text-[11px] font-semibold text-muted-foreground block">
                Total Fees Earned
              </span>
              <p className="font-display text-lg font-bold text-amber-300">
                ${data ? data.totalCommissionEarnedUsd.toFixed(2) : "0.00"}{" "}
                <span className="text-[10px] text-muted-foreground font-normal">USD</span>
              </p>
            </div>

            <div className="rounded-xl border border-cyan-400/30 bg-black/60 p-3.5 space-y-1">
              <span className="text-[11px] font-semibold text-muted-foreground block">
                Total BNB Received
              </span>
              <p className="font-display text-lg font-bold text-cyan-300">
                {data ? data.totalCommissionEarnedBnb.toFixed(4) : "0.0000"}{" "}
                <span className="text-[10px] text-muted-foreground font-normal">BNB</span>
              </p>
            </div>

            <div className="rounded-xl border border-emerald-400/30 bg-black/60 p-3.5 space-y-1">
              <span className="text-[11px] font-semibold text-muted-foreground block">
                Verified Payments
              </span>
              <p className="font-display text-lg font-bold text-emerald-300">
                {data ? data.totalPaymentsCount : 0}{" "}
                <span className="text-[10px] text-muted-foreground font-normal">Txns</span>
              </p>
            </div>
          </div>

          {/* COMMISSION RECEIVING WALLET SETTINGS FORM */}
          <div className="rounded-xl border border-amber-400/40 bg-black/70 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-display text-xs font-bold text-amber-200 flex items-center gap-1.5">
                <Wallet className="h-4 w-4 text-amber-400" /> Commission Receiving Address (BNB Chain)
              </h4>
              {data && (
                <button
                  type="button"
                  onClick={copyAddress}
                  className="flex items-center gap-1 text-xs text-amber-400 hover:text-white"
                >
                  {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                  <span>{copied ? "Copied" : "Copy Current"}</span>
                </button>
              )}
            </div>

            <form onSubmit={handleSaveAddress} className="space-y-3">
              <div className="relative">
                <input
                  type="text"
                  value={addressInput}
                  onChange={(e) => setAddressInput(e.target.value)}
                  placeholder="0x..."
                  className="w-full rounded-lg border border-amber-400/50 bg-black/80 px-3.5 py-2.5 font-mono text-xs text-foreground outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                <span>All service fees from BEP-20 token deployments are sent to this address.</span>
                <button
                  type="submit"
                  disabled={saving || !addressInput || addressInput === data?.adminCommissionAddress}
                  className="py-1.5 px-3 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-50"
                >
                  {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
                  <span>Save Address</span>
                </button>
              </div>
            </form>

            <div className="rounded-lg bg-black/40 border border-emerald-400/30 p-2.5 text-[11px] text-emerald-300 flex items-center gap-2">
              <Lock className="h-3.5 w-3.5 shrink-0 text-emerald-400" />
              <span>
                <strong>Zero Custody / Zero Secret:</strong> Only the public receiving address is stored. Private keys or recovery phrases are never required.
              </span>
            </div>
          </div>

          {/* VERIFIED PAYMENT HISTORY TABLE */}
          <div className="space-y-2">
            <h4 className="font-display text-xs font-bold text-cyan-300 flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-cyan-400" /> Verified Payment Ledger
            </h4>

            {data && data.recentPayments.length > 0 ? (
              <div className="rounded-xl border border-cyan-400/30 bg-black/60 overflow-hidden text-xs">
                <div className="max-h-60 overflow-y-auto divide-y divide-cyan-400/10">
                  {data.recentPayments.map((p) => (
                    <div key={p.id} className="p-3 flex items-center justify-between hover:bg-cyan-500/5 transition-colors">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-foreground">{p.tokenName}</span>
                          <span className="font-mono text-cyan-400">${p.tokenSymbol}</span>
                          <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                            Verified
                          </span>
                        </div>
                        <p className="text-[10px] text-muted-foreground">
                          From: {shortAddress(p.senderAddress)} • {new Date(p.timestamp).toLocaleString()}
                        </p>
                      </div>

                      <div className="text-right space-y-1">
                        <p className="font-mono font-bold text-amber-300">
                          +${p.amountUsd.toFixed(2)} USD{" "}
                          <span className="text-[10px] text-cyan-300 font-normal">({p.amountBnb} BNB)</span>
                        </p>
                        <a
                          href={p.explorerUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-[10px] text-cyan-400 hover:text-white underline"
                        >
                          <ExternalLink className="h-2.5 w-2.5" /> BscScan Tx
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="rounded-xl border border-cyan-400/20 bg-black/40 p-6 text-center text-xs text-muted-foreground space-y-1">
                <Layers className="h-6 w-6 mx-auto text-cyan-400/50" />
                <p>No verified service fee payments recorded yet.</p>
                <p className="text-[11px]">When users deploy BEP-20 tokens, transactions will appear here automatically.</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
