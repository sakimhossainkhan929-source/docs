import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Check,
  Copy,
  ExternalLink,
  Fuel,
  Info,
  Layers,
  Loader2,
  Rocket,
  ShieldCheck,
  Sparkles,
  Wallet,
  Zap,
} from "lucide-react";
import { DemoBadge, Shell } from "@/components/Shell";
import { saveToken, validateToken, type PreviewToken } from "@/lib/tokens";
import { connectWallet, useWallet } from "@/lib/wallet";

export const Route = createFileRoute("/create")({
  head: () => ({
    meta: [
      { title: "Create BEP-20 Token — SAKIM Launchpad" },
      {
        name: "description",
        content:
          "Deploy real BEP-20 tokens on BNB Smart Chain with verified payment validation, flexible service fees, and transparent gas costs.",
      },
      { property: "og:title", content: "Create BEP-20 Token — SAKIM Launchpad" },
      {
        property: "og:description",
        content: "Deploy real BEP-20 tokens on BNB Smart Chain with verified payment validation.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Create,
});

const inputClass =
  "w-full rounded-lg border border-cyan-400/30 bg-black/60 px-4 py-2.5 text-sm text-foreground outline-none focus:border-cyan-400 transition-colors";

const QUICK_AMOUNTS = [
  { label: "$0.50 (Min)", value: "0.50" },
  { label: "$1.00", value: "1.00" },
  { label: "$10.00", value: "10.00" },
  { label: "$100.00", value: "100.00" },
  { label: "$1,000.00", value: "1000.00" },
];

function Create() {
  const nav = useNavigate();
  const wallet = useWallet();

  const [name, setName] = useState("");
  const [symbol, setSymbol] = useState("");
  const [supply, setSupply] = useState("1000000");
  const [logo, setLogo] = useState<string>();
  const [error, setError] = useState<string | null>(null);

  // Payment configuration (Minimum $0.50 USD, no fixed maximum)
  const [paymentAmountUsd, setPaymentAmountUsd] = useState("10.00");
  const [bnbPriceUsd, setBnbPriceUsd] = useState(625.0);
  const [gasFeeUsd, setGasFeeUsd] = useState(0.28);
  const [treasuryAddress, setTreasuryAddress] = useState(
    "0x89205A3A3b2A69De6Dbf7f01ED13B2108B2c43e7",
  );

  // Deployment state
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentStep, setDeploymentStep] = useState<string>("");
  const [deployedToken, setDeployedToken] = useState<{
    contractAddress: string;
    deploymentTxHash: string;
    explorerUrl: string;
    network: string;
    totalPaidUsd: number;
    serviceFeePaidUsd: number;
    gasFeePaidUsd: number;
  } | null>(null);
  const [copied, setCopied] = useState(false);

  // Fetch real-time pricing from backend
  useEffect(() => {
    fetch("/api/token/pricing")
      .then((res) => res.json())
      .then((data) => {
        if (data.bnbPriceUsd) setBnbPriceUsd(data.bnbPriceUsd);
        if (data.estimatedGasFeeUsd) setGasFeeUsd(data.estimatedGasFeeUsd);
        if (data.treasuryAddress) setTreasuryAddress(data.treasuryAddress);
      })
      .catch(() => {
        // use default fallback
      });
  }, []);

  const onLogo = (f?: File) => {
    if (!f) return undefined;
    if (f.size > 300_000) {
      toast.error("Logo must be under 300 KB.");
      return undefined;
    }
    const r = new FileReader();
    r.onload = () => setLogo(r.result as string);
    r.readAsDataURL(f);
    return undefined;
  };

  // Save local preview draft without deployment
  const submitPreviewOnly = (e: React.FormEvent) => {
    e.preventDefault();
    const err = validateToken(name, symbol, supply);
    setError(err);
    if (err) return;

    saveToken({
      id: crypto.randomUUID(),
      name: name.trim(),
      symbol: symbol.trim().toUpperCase(),
      supply: Number(supply),
      logo,
      createdAt: new Date().toISOString(),
      status: "preview",
    });
    toast.success("Draft preview saved", {
      description: "Saved locally. Click 'Deploy BEP-20 Token' to publish on-chain.",
    });
    nav({ to: "/tokens" });
  };

  // Real BEP-20 deployment with backend payment verification
  const handleDeployToken = async () => {
    setError(null);
    const err = validateToken(name, symbol, supply);
    if (err) {
      setError(err);
      return;
    }

    const amountNum = parseFloat(paymentAmountUsd);
    if (isNaN(amountNum) || amountNum < 0.5) {
      setError("Minimum service payment amount is $0.50 USD.");
      toast.error("Invalid payment amount", {
        description: "Minimum service payment amount must be at least $0.50 USD.",
      });
      return;
    }

    setIsDeploying(true);
    setDeploymentStep("validating");

    try {
      // Step 1: Backend validation & payment preparation
      await new Promise((r) => setTimeout(r, 600));
      setDeploymentStep("verifying_payment");

      let txHash: string | undefined = undefined;

      // If Web3 wallet is connected, request payment transfer or signature
      if (wallet.address && typeof window !== "undefined") {
        const eth = (
          window as unknown as { ethereum?: { request: (args: unknown) => Promise<unknown> } }
        ).ethereum;
        if (eth) {
          try {
            // Calculate BNB wei amount for payment
            const bnbAmount = (amountNum / bnbPriceUsd).toFixed(6);
            const weiValue = `0x${BigInt(Math.floor(parseFloat(bnbAmount) * 1e18)).toString(16)}`;

            const userTx = (await eth.request({
              method: "eth_sendTransaction",
              params: [
                {
                  from: wallet.address,
                  to: treasuryAddress,
                  value: weiValue,
                },
              ],
            })) as string;
            txHash = userTx;
          } catch (txErr) {
            console.log(
              "Wallet transfer skipped or cancelled; continuing with verified backend authorization:",
              txErr,
            );
          }
        }
      }

      setDeploymentStep("compiling");
      await new Promise((r) => setTimeout(r, 700));

      // Step 2: Send to backend for strict server-side validation & BEP-20 contract generation
      const res = await fetch("/api/token/deploy", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: {
            name: name.trim(),
            symbol: symbol.trim().toUpperCase(),
            supply: Number(supply),
            logo,
          },
          payment: {
            amountUsd: amountNum,
            currency: "USD",
            txHash,
            senderAddress: wallet.address || undefined,
          },
        }),
      });

      const data = await res.json();

      if (!res.ok || !data.ok || !data.token) {
        throw new Error(data.error || "Backend payment validation failed.");
      }

      setDeploymentStep("confirming");
      await new Promise((r) => setTimeout(r, 600));

      const deployed = data.token;
      setDeployedToken(deployed);

      // Save to My Tokens with deployed status and contract address
      const savedTokenRecord: PreviewToken = {
        id: deployed.id,
        name: deployed.name,
        symbol: deployed.symbol,
        supply: deployed.supply,
        logo,
        createdAt: deployed.deployedAt,
        status: "deployed",
        contractAddress: deployed.contractAddress,
        deploymentTxHash: deployed.deploymentTxHash,
        network: deployed.network,
        serviceFeePaidUsd: deployed.serviceFeePaidUsd,
        gasFeePaidUsd: deployed.gasFeePaidUsd,
        totalPaidUsd: deployed.totalPaidUsd,
        explorerUrl: deployed.explorerUrl,
      };
      saveToken(savedTokenRecord);

      toast.success("BEP-20 Token Deployed!", {
        description: `Contract ${deployed.contractAddress.slice(0, 8)}… active on BNB Smart Chain.`,
      });
    } catch (deployErr) {
      console.error("Token deployment error:", deployErr);
      const msg = deployErr instanceof Error ? deployErr.message : "Deployment failed.";
      setError(msg);
      toast.error("Deployment Error", { description: msg });
    } finally {
      setIsDeploying(false);
      setDeploymentStep("");
    }
  };

  const copyContract = () => {
    if (!deployedToken?.contractAddress) return;
    navigator.clipboard.writeText(deployedToken.contractAddress);
    setCopied(true);
    toast.success("Contract address copied!");
    setTimeout(() => setCopied(false), 2000);
  };

  const parsedAmount = parseFloat(paymentAmountUsd) || 0;
  const serviceBnb = (parsedAmount / bnbPriceUsd).toFixed(5);
  const gasBnb = (gasFeeUsd / bnbPriceUsd).toFixed(5);
  const totalBnb = ((parsedAmount + gasFeeUsd) / bnbPriceUsd).toFixed(5);
  const sym = symbol.trim().toUpperCase() || "SYM";

  return (
    <Shell title="Create Token">
      <div className="grid gap-6 md:grid-cols-2">
        {/* LEFT COLUMN: Token Form & Payment Configuration */}
        <div className="space-y-6">
          {/* 1. Token Parameters */}
          <div className="glass space-y-4 p-6 border border-cyan-400/30">
            <div className="flex items-center justify-between border-b border-cyan-400/20 pb-3">
              <h3 className="font-display font-bold text-cyan-300 flex items-center gap-2">
                <Sparkles className="h-4 w-4" /> Token Parameters
              </h3>
              <span className="text-xs px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-400/30">
                BEP-20 Standard
              </span>
            </div>

            <label className="block text-sm">
              Token name
              <input
                className={inputClass}
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Sakim AI Coin"
              />
            </label>

            <label className="block text-sm">
              Symbol
              <input
                className={inputClass}
                value={symbol}
                onChange={(e) => setSymbol(e.target.value)}
                placeholder="SAKIM"
                maxLength={10}
              />
            </label>

            <label className="block text-sm">
              Total supply
              <input
                className={inputClass}
                value={supply}
                onChange={(e) => setSupply(e.target.value.replace(/\D/g, ""))}
                inputMode="numeric"
                placeholder="1000000"
              />
            </label>

            <label className="block text-sm">
              Logo (optional)
              <input
                type="file"
                accept="image/*"
                className={inputClass}
                onChange={(e) => onLogo(e.target.files?.[0])}
              />
            </label>
          </div>

          {/* 2. Payment & Real BEP-20 Deployment System */}
          <div className="glass space-y-4 p-6 border border-amber-400/40 bg-black/40">
            <div className="flex items-center justify-between border-b border-amber-400/20 pb-3">
              <h3 className="font-display font-bold text-amber-300 flex items-center gap-2">
                <ShieldCheck className="h-4 w-4" /> Payment &amp; Deployment Verification
              </h3>
              <span className="text-[11px] font-semibold text-amber-400">
                Min: $0.50 USD • No Max
              </span>
            </div>

            {/* Quick Amount Tier Selector */}
            <div>
              <label className="block text-xs font-semibold text-muted-foreground mb-1.5">
                Service Payment Amount ($ USD)
              </label>
              <div className="grid grid-cols-5 gap-1.5 mb-2">
                {QUICK_AMOUNTS.map((q) => (
                  <button
                    key={q.value}
                    type="button"
                    onClick={() => setPaymentAmountUsd(q.value)}
                    className={`py-1.5 px-1 rounded text-center text-xs font-bold transition-all border ${
                      paymentAmountUsd === q.value
                        ? "bg-amber-400 text-black border-amber-300 shadow-[0_0_10px_rgba(255,208,91,0.5)]"
                        : "bg-black/60 text-amber-200 border-amber-400/30 hover:border-amber-400"
                    }`}
                  >
                    {q.label}
                  </button>
                ))}
              </div>

              {/* Custom Amount Input with No Maximum */}
              <div className="relative">
                <span className="absolute left-3.5 top-2.5 text-sm font-bold text-amber-300">
                  $
                </span>
                <input
                  type="number"
                  min="0.50"
                  step="0.01"
                  value={paymentAmountUsd}
                  onChange={(e) => setPaymentAmountUsd(e.target.value)}
                  placeholder="Enter amount (min 0.50, e.g. 10, 100, 1000...)"
                  className="w-full rounded-lg border border-amber-400/50 bg-black/70 pl-8 pr-16 py-2.5 text-sm text-foreground outline-none focus:border-amber-400"
                />
                <span className="absolute right-3.5 top-2.5 text-xs font-bold text-muted-foreground">
                  USD
                </span>
              </div>
              <p className="mt-1 text-[11px] text-muted-foreground">
                Enter any service amount ($0.50, $1, $10, $100, $1,000 or higher). Payments are
                strictly verified on the backend.
              </p>
            </div>

            {/* Transparent Fee Breakdown Box */}
            <div className="rounded-lg border border-cyan-400/30 bg-cyan-950/20 p-3.5 space-y-2 text-xs">
              <div className="flex items-center justify-between text-muted-foreground">
                <span className="flex items-center gap-1.5 text-cyan-200">
                  <Zap className="h-3.5 w-3.5 text-cyan-400" /> Platform Service Fee:
                </span>
                <span className="font-mono font-bold text-foreground">
                  ${parsedAmount.toFixed(2)} USD{" "}
                  <span className="text-cyan-400 font-normal">({serviceBnb} BNB)</span>
                </span>
              </div>

              <div className="flex items-center justify-between text-muted-foreground">
                <span className="flex items-center gap-1.5 text-cyan-200">
                  <Fuel className="h-3.5 w-3.5 text-amber-400" /> Blockchain Gas Fee (BNB Chain):
                </span>
                <span className="font-mono font-bold text-foreground">
                  ${gasFeeUsd.toFixed(2)} USD{" "}
                  <span className="text-amber-400 font-normal">({gasBnb} BNB)</span>
                </span>
              </div>

              <div className="border-t border-cyan-400/20 pt-2 flex items-center justify-between font-bold text-sm">
                <span className="text-cyan-300">Total Deployment Cost:</span>
                <span className="text-amber-300 font-mono">
                  ${(parsedAmount + gasFeeUsd).toFixed(2)} USD{" "}
                  <span className="text-xs text-white">({totalBnb} BNB)</span>
                </span>
              </div>
            </div>

            {/* Wallet Status / Connect Button */}
            <div className="flex items-center justify-between text-xs px-2 py-1.5 bg-black/40 rounded border border-cyan-400/20">
              <span className="flex items-center gap-1.5 text-muted-foreground">
                <Wallet className="h-3.5 w-3.5 text-cyan-400" />
                {wallet.address ? (
                  <span className="text-cyan-300">
                    Connected: {wallet.address.slice(0, 6)}…{wallet.address.slice(-4)}
                  </span>
                ) : (
                  <span>MetaMask Not Connected (optional)</span>
                )}
              </span>
              {!wallet.address && (
                <button
                  type="button"
                  onClick={() => void connectWallet()}
                  className="text-cyan-400 hover:text-white underline text-xs font-semibold"
                >
                  Connect
                </button>
              )}
            </div>

            {error && (
              <p
                role="alert"
                className="text-xs text-red-400 bg-red-950/30 p-2.5 rounded border border-red-500/40"
              >
                {error}
              </p>
            )}

            {/* Deployment Action Buttons */}
            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                type="button"
                onClick={submitPreviewOnly}
                disabled={isDeploying}
                className="w-full rounded-xl py-3 border border-cyan-400/40 bg-black/40 hover:bg-cyan-500/10 text-cyan-300 font-display font-semibold text-xs transition-colors"
              >
                Save Draft Preview
              </button>

              <button
                type="button"
                onClick={handleDeployToken}
                disabled={isDeploying}
                className="btn-neon w-full rounded-xl py-3 font-display font-bold text-xs flex items-center justify-center gap-1.5"
              >
                {isDeploying ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>
                      {deploymentStep === "validating"
                        ? "Validating..."
                        : deploymentStep === "verifying_payment"
                          ? "Verifying..."
                          : "Deploying..."}
                    </span>
                  </>
                ) : (
                  <>
                    <Rocket className="h-4 w-4" />
                    <span>Deploy BEP-20 Token</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Live Card Preview & Verified Deployment Result */}
        <div className="space-y-6">
          {/* Deployed Token Confirmation Card */}
          {deployedToken ? (
            <div className="glass space-y-4 p-6 border-2 border-green-400 bg-green-950/20 text-center animate-in fade-in zoom-in-95">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-green-500/20 text-green-300 border border-green-400 text-xs font-bold">
                <Check className="h-3.5 w-3.5" /> BEP-20 Token Deployed &amp; Verified
              </div>

              <div className="grid h-24 w-24 mx-auto place-items-center overflow-hidden rounded-full border-2 border-green-400 shadow-[0_0_20px_rgba(34,197,94,0.4)]">
                {logo ? (
                  <img src={logo} alt="Logo" className="h-full w-full object-cover" />
                ) : (
                  <span className="font-display text-2xl font-extrabold text-green-300">
                    {sym.slice(0, 3)}
                  </span>
                )}
              </div>

              <div>
                <h2 className="font-display text-xl font-bold text-white">{name}</h2>
                <p className="text-green-400 font-mono font-bold">${sym}</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Supply: {Number(supply).toLocaleString()} BEP-20 Tokens
                </p>
              </div>

              {/* Contract Address with Copy */}
              <div className="rounded-lg border border-green-400/40 bg-black/60 p-3 text-left space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Contract Address:</span>
                  <button
                    type="button"
                    onClick={copyContract}
                    className="flex items-center gap-1 text-green-400 hover:text-white"
                  >
                    {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    <span>{copied ? "Copied" : "Copy"}</span>
                  </button>
                </div>
                <p className="font-mono text-xs text-green-200 break-all select-all">
                  {deployedToken.contractAddress}
                </p>
              </div>

              {/* Deployment Details */}
              <div className="grid grid-cols-2 gap-2 text-xs text-left">
                <div className="p-2 rounded bg-black/40 border border-cyan-400/20">
                  <span className="text-muted-foreground block text-[10px]">Network</span>
                  <span className="font-semibold text-cyan-300">BNB Smart Chain</span>
                </div>
                <div className="p-2 rounded bg-black/40 border border-cyan-400/20">
                  <span className="text-muted-foreground block text-[10px]">Verified Fee Paid</span>
                  <span className="font-semibold text-amber-300">
                    ${deployedToken.totalPaidUsd.toFixed(2)} USD
                  </span>
                </div>
              </div>

              {/* Links */}
              <div className="flex gap-2 pt-2">
                <a
                  href={deployedToken.explorerUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-2.5 px-3 rounded-xl border border-cyan-400/50 bg-cyan-950/30 text-cyan-300 text-xs font-bold hover:bg-cyan-500/20 flex items-center justify-center gap-1.5"
                >
                  <ExternalLink className="h-3.5 w-3.5" /> View on BscScan
                </a>
                <button
                  type="button"
                  onClick={() => nav({ to: "/tokens" })}
                  className="flex-1 py-2.5 px-3 rounded-xl bg-cyan-500 text-black text-xs font-bold hover:bg-cyan-400 flex items-center justify-center gap-1.5"
                >
                  <Layers className="h-3.5 w-3.5" /> View in My Tokens
                </button>
              </div>
            </div>
          ) : (
            /* Live Token Preview Card */
            <div className="glass flex flex-col items-center justify-center gap-4 p-8 text-center border border-cyan-400/30">
              <DemoBadge label="Live Token Preview" />
              <div className="grid h-28 w-28 place-items-center overflow-hidden rounded-full border-2 border-primary shadow-[var(--shadow-neon)]">
                {logo ? (
                  <img src={logo} alt="Logo" className="h-full w-full object-cover" />
                ) : (
                  <span className="font-display text-2xl font-extrabold text-neon">
                    {sym.slice(0, 3)}
                  </span>
                )}
              </div>
              <div>
                <h2 className="font-display text-xl font-bold">{name || "Your Token"}</h2>
                <p className="text-primary font-mono">${sym}</p>
              </div>
              <div className="w-full border-t border-cyan-400/20 pt-3 space-y-1.5 text-xs text-muted-foreground">
                <div className="flex justify-between">
                  <span>Total Supply:</span>
                  <span className="text-foreground font-mono">
                    {Number(supply || 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Standard:</span>
                  <span className="text-cyan-300">BEP-20 (BNB Chain)</span>
                </div>
                <div className="flex justify-between">
                  <span>Platform Service Fee:</span>
                  <span className="text-amber-300 font-mono">${parsedAmount.toFixed(2)} USD</span>
                </div>
                <div className="flex justify-between">
                  <span>Est. Network Gas:</span>
                  <span className="text-cyan-400 font-mono">${gasFeeUsd.toFixed(2)} USD</span>
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                <Info className="h-3 w-3" /> Real BEP-20 contract is deployed only after payment
                verification.
              </p>
            </div>
          )}
        </div>
      </div>
    </Shell>
  );
}
